(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/status/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AppliedCompanyStatusPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/base.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const API_URL = "".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api");
/* ---------- UI helpers ---------- */ function StatusBadge(param) {
    let { status } = param;
    const base = "px-3 py-1 rounded-md text-sm font-semibold";
    if (status === "Approved") return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "".concat(base, " bg-yellow-100 text-yellow-800 border border-yellow-300"),
        children: "Approved"
    }, void 0, false, {
        fileName: "[project]/src/app/status/page.tsx",
        lineNumber: 24,
        columnNumber: 12
    }, this);
    if (status === "Confirmed") return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "".concat(base, " bg-green-100 text-green-700 border border-green-300"),
        children: "Confirmed"
    }, void 0, false, {
        fileName: "[project]/src/app/status/page.tsx",
        lineNumber: 26,
        columnNumber: 12
    }, this);
    if (status === "Pending") return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "".concat(base, " bg-gray-100 text-gray-700 border border-gray-300"),
        children: "Pending"
    }, void 0, false, {
        fileName: "[project]/src/app/status/page.tsx",
        lineNumber: 28,
        columnNumber: 12
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "".concat(base, " bg-red-100 text-red-700 border border-red-300"),
        children: "Declined"
    }, void 0, false, {
        fileName: "[project]/src/app/status/page.tsx",
        lineNumber: 29,
        columnNumber: 10
    }, this);
}
_c = StatusBadge;
function AppliedCompanyStatusPage() {
    _s();
    const [applications, setApplications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const { user, isReady } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AppliedCompanyStatusPage.useEffect": ()=>{
            const fetchApplications = {
                "AppliedCompanyStatusPage.useEffect.fetchApplications": async ()=>{
                    if (!isReady) return;
                    if (!user) {
                        setLoading(false);
                        return;
                    }
                    try {
                        const res = await fetch("".concat(API_URL, "/employee/my-applications"), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
                            method: "GET",
                            credentials: "include"
                        }));
                        if (!res.ok) {
                            console.error("❌ Request failed:", res.status, await res.text());
                            setLoading(false);
                            return;
                        }
                        const json = await res.json();
                        const data = Array.isArray(json === null || json === void 0 ? void 0 : json.data) ? json.data : Array.isArray(json) ? json : [];
                        const mapped = data.map({
                            "AppliedCompanyStatusPage.useEffect.fetchApplications.mapped": (a)=>{
                                var _a_job_post, _a_job_post1, _a_job_post_company, _a_job_post2, _a_job_post3, _a_job_post4;
                                var _a_job_post_position, _ref, _ref1;
                                const position = (_ref1 = (_ref = (_a_job_post_position = a === null || a === void 0 ? void 0 : (_a_job_post = a.job_post) === null || _a_job_post === void 0 ? void 0 : _a_job_post.position) !== null && _a_job_post_position !== void 0 ? _a_job_post_position : a === null || a === void 0 ? void 0 : (_a_job_post1 = a.job_post) === null || _a_job_post1 === void 0 ? void 0 : _a_job_post1.job_title) !== null && _ref !== void 0 ? _ref : a === null || a === void 0 ? void 0 : a.position) !== null && _ref1 !== void 0 ? _ref1 : "—";
                                var _a_job_post_company_company_name, _a_job_post_company_id, _ref2;
                                const companyName = (_ref2 = (_a_job_post_company_company_name = a === null || a === void 0 ? void 0 : (_a_job_post2 = a.job_post) === null || _a_job_post2 === void 0 ? void 0 : (_a_job_post_company = _a_job_post2.company) === null || _a_job_post_company === void 0 ? void 0 : _a_job_post_company.company_name) !== null && _a_job_post_company_company_name !== void 0 ? _a_job_post_company_company_name : a === null || a === void 0 ? void 0 : (_a_job_post3 = a.job_post) === null || _a_job_post3 === void 0 ? void 0 : _a_job_post3.company_name) !== null && _ref2 !== void 0 ? _ref2 : "Company #".concat((_a_job_post_company_id = a === null || a === void 0 ? void 0 : (_a_job_post4 = a.job_post) === null || _a_job_post4 === void 0 ? void 0 : _a_job_post4.company_id) !== null && _a_job_post_company_id !== void 0 ? _a_job_post_company_id : "-");
                                var _a_applied_at, _ref3;
                                const appliedAt = (_ref3 = (_a_applied_at = a === null || a === void 0 ? void 0 : a.applied_at) !== null && _a_applied_at !== void 0 ? _a_applied_at : a === null || a === void 0 ? void 0 : a.created_at) !== null && _ref3 !== void 0 ? _ref3 : null;
                                var _a_employee_send_status;
                                const emp = ((_a_employee_send_status = a === null || a === void 0 ? void 0 : a.employee_send_status) !== null && _a_employee_send_status !== void 0 ? _a_employee_send_status : "").toString().toLowerCase();
                                var _a_company_send_status;
                                const comp = ((_a_company_send_status = a === null || a === void 0 ? void 0 : a.company_send_status) !== null && _a_company_send_status !== void 0 ? _a_company_send_status : "").toString().toLowerCase();
                                // สถานะสำหรับคอลัมน์ UI
                                let status = "Pending";
                                if (emp === "confirmed") status = "Confirmed";
                                else if (emp === "rejected") status = "Declined";
                                else if (comp === "approved" || comp === "confirmed") status = "Approved";
                                // อนุญาตให้กด Confirm เมื่อบริษัทเป็น approved หรือ confirmed
                                const canConfirm = comp === "approved" || comp === "confirmed";
                                var _a_id;
                                return {
                                    id: Number((_a_id = a === null || a === void 0 ? void 0 : a.id) !== null && _a_id !== void 0 ? _a_id : 0),
                                    company_name: companyName,
                                    position,
                                    applied_date: appliedAt ? new Date(appliedAt).toLocaleDateString() : "—",
                                    status,
                                    canConfirm
                                };
                            }
                        }["AppliedCompanyStatusPage.useEffect.fetchApplications.mapped"]);
                        setApplications(mapped);
                    } catch (err) {
                        console.error("🔥 Error while fetching applications:", err);
                    } finally{
                        setLoading(false);
                    }
                }
            }["AppliedCompanyStatusPage.useEffect.fetchApplications"];
            fetchApplications();
        }
    }["AppliedCompanyStatusPage.useEffect"], [
        user,
        isReady
    ]);
    /* ---------- Actions ---------- */ const handleConfirm = async (id)=>{
        if (!user) return;
        try {
            const res = await fetch("".concat(API_URL, "/employee/job-applications/").concat(id, "/confirm"), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
                method: "POST",
                credentials: "include"
            }));
            if (res.ok) {
                setApplications((prev)=>prev.map((a)=>a.id === id ? {
                            ...a,
                            status: "Confirmed",
                            canConfirm: false
                        } : a));
            } else {
                const msg = await res.text();
                console.error("Confirm failed:", msg);
                try {
                    const j = JSON.parse(msg);
                    alert((j === null || j === void 0 ? void 0 : j.message) || msg);
                } catch (e) {
                    alert(msg);
                }
            }
        } catch (err) {
            console.error("Confirm error:", err);
            alert("Confirm failed. Please try again.");
        }
    };
    const handleCancel = async (id)=>{
        if (!user) return;
        try {
            const res = await fetch("".concat(API_URL, "/employee/cancel-application/").concat(id), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
                method: "DELETE",
                credentials: "include"
            }));
            if (res.ok) {
                setApplications((prev)=>prev.filter((a)=>a.id !== id));
            } else {
                const msg = await res.text();
                console.error("Cancel failed:", msg);
                alert("Cancel failed: " + msg);
            }
        } catch (err) {
            console.error("Cancel error:", err);
            alert("Cancel failed. Please try again.");
        }
    };
    /* ---------- UI ---------- */ if (loading || !isReady) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen flex items-center justify-center text-gray-600 text-lg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Loading applications..."
                    }, void 0, false, {
                        fileName: "[project]/src/app/status/page.tsx",
                        lineNumber: 161,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-gray-400",
                        children: "(See browser console for debug logs)"
                    }, void 0, false, {
                        fileName: "[project]/src/app/status/page.tsx",
                        lineNumber: 162,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/status/page.tsx",
                lineNumber: 160,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/status/page.tsx",
            lineNumber: 159,
            columnNumber: 7
        }, this);
    }
    if (!user) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen flex items-center justify-center text-gray-600 text-lg",
            children: "Please log in to view your applications."
        }, void 0, false, {
            fileName: "[project]/src/app/status/page.tsx",
            lineNumber: 170,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-gray-50 py-10 font-sans",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-5xl mx-auto bg-white rounded-2xl shadow-md p-10 border border-gray-100",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-3xl font-extrabold text-gray-900 mb-8",
                    children: "Applied Company Status"
                }, void 0, false, {
                    fileName: "[project]/src/app/status/page.tsx",
                    lineNumber: 179,
                    columnNumber: 9
                }, this),
                applications.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-center text-gray-500 py-10",
                    children: "No applications found."
                }, void 0, false, {
                    fileName: "[project]/src/app/status/page.tsx",
                    lineNumber: 182,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "overflow-x-auto rounded-lg border border-gray-100 shadow-sm",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: "w-full border-collapse text-gray-800",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    className: "bg-[#558E46] text-white text-left",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "p-4",
                                            children: "Company"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/status/page.tsx",
                                            lineNumber: 188,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "p-4",
                                            children: "Position"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/status/page.tsx",
                                            lineNumber: 189,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "p-4",
                                            children: "Applied Date"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/status/page.tsx",
                                            lineNumber: 190,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "p-4",
                                            children: "Status"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/status/page.tsx",
                                            lineNumber: 191,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            className: "p-4 text-center",
                                            children: "Action"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/status/page.tsx",
                                            lineNumber: 192,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/status/page.tsx",
                                    lineNumber: 187,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/status/page.tsx",
                                lineNumber: 186,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: applications.map((app)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: "border-b hover:bg-gray-50 transition",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "p-4 font-medium",
                                                children: app.company_name
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/status/page.tsx",
                                                lineNumber: 198,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "p-4",
                                                children: app.position
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/status/page.tsx",
                                                lineNumber: 199,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "p-4",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "bg-gray-100 rounded-md px-3 py-1 text-sm",
                                                    children: app.applied_date
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/status/page.tsx",
                                                    lineNumber: 201,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/status/page.tsx",
                                                lineNumber: 200,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "p-4",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StatusBadge, {
                                                    status: app.status
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/status/page.tsx",
                                                    lineNumber: 204,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/status/page.tsx",
                                                lineNumber: 203,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "p-4 text-center",
                                                children: app.status === "Approved" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex justify-center gap-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>app.canConfirm ? handleConfirm(app.id) : undefined,
                                                            disabled: !app.canConfirm,
                                                            title: !app.canConfirm ? "Company must confirm before you can confirm." : undefined,
                                                            className: "px-3 py-1 rounded-md text-white transition ".concat(app.canConfirm ? "bg-[#558E46] hover:bg-[#4a7b3d]" : "bg-gray-300 cursor-not-allowed"),
                                                            children: "Confirm"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/status/page.tsx",
                                                            lineNumber: 209,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleCancel(app.id),
                                                            className: "bg-red-500 text-white px-3 py-1 rounded-md hover:bg-red-600 transition",
                                                            children: "Cancel"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/status/page.tsx",
                                                            lineNumber: 219,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/status/page.tsx",
                                                    lineNumber: 208,
                                                    columnNumber: 25
                                                }, this) : app.status === "Pending" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>handleCancel(app.id),
                                                    className: "bg-red-500 text-white px-3 py-1 rounded-md hover:bg-red-600 transition",
                                                    children: "Cancel"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/status/page.tsx",
                                                    lineNumber: 227,
                                                    columnNumber: 25
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-gray-500 text-sm",
                                                    children: "No Action"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/status/page.tsx",
                                                    lineNumber: 234,
                                                    columnNumber: 25
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/status/page.tsx",
                                                lineNumber: 206,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, app.id, true, {
                                        fileName: "[project]/src/app/status/page.tsx",
                                        lineNumber: 197,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/status/page.tsx",
                                lineNumber: 195,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/status/page.tsx",
                        lineNumber: 185,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/status/page.tsx",
                    lineNumber: 184,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/status/page.tsx",
            lineNumber: 178,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/status/page.tsx",
        lineNumber: 177,
        columnNumber: 5
    }, this);
}
_s(AppliedCompanyStatusPage, "WWzZkNbTelwpzA51RpvpxJ9ujog=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"]
    ];
});
_c1 = AppliedCompanyStatusPage;
var _c, _c1;
__turbopack_context__.k.register(_c, "StatusBadge");
__turbopack_context__.k.register(_c1, "AppliedCompanyStatusPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_app_status_page_tsx_29da5497._.js.map