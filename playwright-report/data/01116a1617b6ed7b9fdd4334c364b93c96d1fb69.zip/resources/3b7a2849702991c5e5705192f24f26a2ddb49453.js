(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/EditJobModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EditJobModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function EditJobModal(param) {
    let { isOpen, onClose, initial, onSave, brandColor = "#5D9252", mode = "edit" } = param;
    _s();
    // === Local state ===
    const [title, setTitle] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [position, setPosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [details, setDetails] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [positionsAvailable, setPositionsAvailable] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [jobType, setJobType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [requirements, setRequirements] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [location, setLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [expectedSalaryMin, setExpectedSalaryMin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [expectedSalaryMax, setExpectedSalaryMax] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [workType, setWorkType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [expiredAt, setExpiredAt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const overlayRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const firstFieldRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // === Load data when modal opens ===
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "EditJobModal.useEffect": ()=>{
            if (!isOpen) return;
            const src = initial || (mode === "create" ? {
                title: "",
                position: "",
                details: "",
                positionsAvailable: 1
            } : null);
            if (!src) return;
            var _src_title;
            setTitle((_src_title = src.title) !== null && _src_title !== void 0 ? _src_title : "");
            var _src_position;
            setPosition((_src_position = src.position) !== null && _src_position !== void 0 ? _src_position : "");
            var _src_details;
            setDetails((_src_details = src.details) !== null && _src_details !== void 0 ? _src_details : "");
            var _src_positionsAvailable;
            setPositionsAvailable((_src_positionsAvailable = src.positionsAvailable) !== null && _src_positionsAvailable !== void 0 ? _src_positionsAvailable : "");
            var _src_jobType;
            setJobType((_src_jobType = src.jobType) !== null && _src_jobType !== void 0 ? _src_jobType : mode === "create" ? "Full Time" : "");
            var _src_location;
            setLocation((_src_location = src.location) !== null && _src_location !== void 0 ? _src_location : "");
            setExpectedSalaryMin(src.minimum_expected_salary != null ? String(src.minimum_expected_salary) : "");
            setExpectedSalaryMax(src.maximum_expected_salary != null ? String(src.maximum_expected_salary) : "");
            var _src_workType;
            setWorkType((_src_workType = src.workType) !== null && _src_workType !== void 0 ? _src_workType : "");
            setExpiredAt(src.expired_at ? String(src.expired_at).slice(0, 10) : "");
            setTimeout({
                "EditJobModal.useEffect": ()=>{
                    var _firstFieldRef_current;
                    return (_firstFieldRef_current = firstFieldRef.current) === null || _firstFieldRef_current === void 0 ? void 0 : _firstFieldRef_current.focus();
                }
            }["EditJobModal.useEffect"], 0);
        }
    }["EditJobModal.useEffect"], [
        isOpen,
        initial,
        mode
    ]);
    if (!isOpen || !initial && mode !== "create") return null;
    // === Validation ===
    const canSave = Boolean(title && position && details && positionsAvailable && jobType && location && workType && expectedSalaryMin !== "" && expectedSalaryMax !== "" && Number(expectedSalaryMin) > 0 && Number(expectedSalaryMax) > 0 && Number(expectedSalaryMin) <= Number(expectedSalaryMax));
    // === Prisma-compatible position enums ===
    const positionOptions = [
        {
            label: "Backend Developer",
            value: "Backend_Developer"
        },
        {
            label: "Frontend Developer",
            value: "Frontend_Developer"
        },
        {
            label: "Fullstack Developer",
            value: "Fullstack_Developer"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: overlayRef,
        className: "fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4",
        onMouseDown: (e)=>{
            if (e.target === overlayRef.current) onClose();
        },
        role: "dialog",
        "aria-modal": "true",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-[40em] rounded-2xl bg-white shadow-xl transition-all",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between px-5 py-4 border-b",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-lg font-semibold",
                            children: mode === 'create' ? 'Post a Job' : 'Edit Job Posting'
                        }, void 0, false, {
                            fileName: "[project]/src/components/EditJobModal.tsx",
                            lineNumber: 112,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "inline-flex h-8 w-8 items-center justify-center rounded-full text-gray-500 hover:bg-gray-100",
                            "aria-label": "Close",
                            children: "✕"
                        }, void 0, false, {
                            fileName: "[project]/src/components/EditJobModal.tsx",
                            lineNumber: 113,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/EditJobModal.tsx",
                    lineNumber: 111,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-4 px-5 py-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: position,
                                    onChange: (e)=>{
                                        const v = e.target.value;
                                        setPosition(v);
                                    },
                                    className: "w-1/2 rounded-md border px-3 py-2 text-sm focus:ring-2",
                                    style: {
                                        outlineColor: brandColor
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            children: "Choose Position"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 135,
                                            columnNumber: 15
                                        }, this),
                                        positionOptions.map((p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: p.value,
                                                children: p.label
                                            }, p.value, false, {
                                                fileName: "[project]/src/components/EditJobModal.tsx",
                                                lineNumber: 137,
                                                columnNumber: 17
                                            }, this))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                    lineNumber: 126,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    ref: firstFieldRef,
                                    type: "text",
                                    value: title,
                                    onChange: (e)=>setTitle(e.target.value),
                                    placeholder: "Job title",
                                    className: "flex-1 rounded-md border px-3 py-2 text-sm focus:ring-2",
                                    style: {
                                        outlineColor: brandColor
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                    lineNumber: 143,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/EditJobModal.tsx",
                            lineNumber: 125,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            value: details,
                            onChange: (e)=>setDetails(e.target.value),
                            className: "h-32 w-full rounded-md border px-3 py-2 text-sm focus:ring-2",
                            style: {
                                outlineColor: brandColor
                            },
                            placeholder: "Enter job description…"
                        }, void 0, false, {
                            fileName: "[project]/src/components/EditJobModal.tsx",
                            lineNumber: 155,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-xs text-gray-500",
                            children: "Description supports basic Markdown (headings, lists, bold/italic, links, code)."
                        }, void 0, false, {
                            fileName: "[project]/src/components/EditJobModal.tsx",
                            lineNumber: 162,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-medium text-gray-700",
                                    children: "Number of Positions Available"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                    lineNumber: 166,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "number",
                                    min: 1,
                                    className: "w-24 rounded-md border px-3 py-2 text-sm text-center focus:ring-2",
                                    style: {
                                        outlineColor: brandColor
                                    },
                                    value: positionsAvailable,
                                    onChange: (e)=>setPositionsAvailable(e.target.value ? Number(e.target.value) : "")
                                }, void 0, false, {
                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                    lineNumber: 169,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/EditJobModal.tsx",
                            lineNumber: 165,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-medium text-gray-700",
                                    children: "Job Type"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                    lineNumber: 183,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    className: "rounded-md border px-3 py-2 text-sm focus:ring-2",
                                    style: {
                                        outlineColor: brandColor
                                    },
                                    value: jobType,
                                    onChange: (e)=>setJobType(e.target.value),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            children: "Select type"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 190,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: "Full Time"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 191,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: "Part Time"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 192,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: "Internship"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 193,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: "Contract"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 194,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                    lineNumber: 184,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/EditJobModal.tsx",
                            lineNumber: 182,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid sm:grid-cols-2 gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-medium text-gray-700",
                                            children: "Location"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 201,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            className: "rounded-md border px-3 py-2 text-sm focus:ring-2",
                                            style: {
                                                outlineColor: brandColor
                                            },
                                            value: location,
                                            onChange: (e)=>setLocation(e.target.value),
                                            placeholder: "City / Remote"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 202,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                    lineNumber: 200,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-medium text-gray-700",
                                            children: "Expected Salary (Min - Max)"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 205,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    className: "w-32 rounded-md border px-3 py-2 text-sm focus:ring-2",
                                                    style: {
                                                        outlineColor: brandColor
                                                    },
                                                    value: expectedSalaryMin,
                                                    onChange: (e)=>setExpectedSalaryMin(e.target.value),
                                                    placeholder: "18000"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                                    lineNumber: 207,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: "-"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                                    lineNumber: 208,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    className: "w-32 rounded-md border px-3 py-2 text-sm focus:ring-2",
                                                    style: {
                                                        outlineColor: brandColor
                                                    },
                                                    value: expectedSalaryMax,
                                                    onChange: (e)=>setExpectedSalaryMax(e.target.value),
                                                    placeholder: "30000"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                                    lineNumber: 209,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 206,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                    lineNumber: 204,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/EditJobModal.tsx",
                            lineNumber: 199,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid sm:grid-cols-2 gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-medium text-gray-700",
                                            children: "Work Place"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 215,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                            className: "rounded-md border px-3 py-2 text-sm focus:ring-2",
                                            style: {
                                                outlineColor: brandColor
                                            },
                                            value: workType,
                                            onChange: (e)=>setWorkType(e.target.value),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: "",
                                                    children: "Select"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                                    lineNumber: 217,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: "OnSite",
                                                    children: "On-site"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                                    lineNumber: 218,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: "Online",
                                                    children: "Online"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                                    lineNumber: 219,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                    value: "Hybrid",
                                                    children: "Hybrid"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                                    lineNumber: 220,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 216,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                    lineNumber: 214,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "grid gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "text-sm font-medium text-gray-700",
                                            children: [
                                                "Expiration Date ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-gray-400 font-normal",
                                                    children: "(optional)"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                                    lineNumber: 224,
                                                    columnNumber: 84
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 224,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "date",
                                            className: "rounded-md border px-3 py-2 text-sm focus:ring-2",
                                            style: {
                                                outlineColor: brandColor
                                            },
                                            value: expiredAt,
                                            onChange: (e)=>setExpiredAt(e.target.value)
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/EditJobModal.tsx",
                                            lineNumber: 225,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/EditJobModal.tsx",
                                    lineNumber: 223,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/EditJobModal.tsx",
                            lineNumber: 213,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/EditJobModal.tsx",
                    lineNumber: 123,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-end gap-2 rounded-b-2xl bg-gray-50 px-5 py-3 border-t",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "rounded-full border px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition",
                            children: "Cancel"
                        }, void 0, false, {
                            fileName: "[project]/src/components/EditJobModal.tsx",
                            lineNumber: 232,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            disabled: !canSave,
                            onClick: ()=>canSave && onSave({
                                    title,
                                    position,
                                    details,
                                    positionsAvailable: Number(positionsAvailable),
                                    jobType,
                                    location,
                                    minimum_expected_salary: expectedSalaryMin ? Number(expectedSalaryMin) : undefined,
                                    maximum_expected_salary: expectedSalaryMax ? Number(expectedSalaryMax) : undefined,
                                    expired_at: expiredAt || null,
                                    workType
                                }),
                            className: "rounded-full px-5 py-2 text-sm font-semibold text-white disabled:opacity-50 transition",
                            style: {
                                backgroundColor: brandColor
                            },
                            children: mode === 'create' ? 'Create Job' : 'Save changes'
                        }, void 0, false, {
                            fileName: "[project]/src/components/EditJobModal.tsx",
                            lineNumber: 239,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/EditJobModal.tsx",
                    lineNumber: 231,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/EditJobModal.tsx",
            lineNumber: 109,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/EditJobModal.tsx",
        lineNumber: 100,
        columnNumber: 5
    }, this);
}
_s(EditJobModal, "2RTWceJJPStQ1oPl9gG7g+34/xw=");
_c = EditJobModal;
var _c;
__turbopack_context__.k.register(_c, "EditJobModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/company/jobpostings/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DashboardPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EditJobModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/EditJobModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/base.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const BASE_URL = ("TURBOPACK compile-time value", "http://localhost:8000") || "http://localhost:8000";
const API_URL_BASE = "".concat(BASE_URL, "/api/company/job-postings");
const API_URL_GET_ALL = "".concat(API_URL_BASE, "/all");
async function fetchAuthedJson(url) {
    let init = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    const res = await fetch(url, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
        credentials: "include",
        ...init
    }));
    if (!res.ok) {
        const text = await res.text().catch(()=>"");
        throw new Error("HTTP ".concat(res.status, " ").concat(text));
    }
    return res.json();
}
function DashboardPage() {
    var _jobs_editIndex, _jobs_editIndex1, _jobs_editIndex2, _jobs_editIndex3, _jobs_editIndex4, _jobs_editIndex5, _jobs_editIndex6, _jobs_editIndex7, _jobs_editIndex8, _jobs_editIndex9, _jobs_editIndex10;
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { user, isReady } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const isCompany = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "DashboardPage.useMemo[isCompany]": ()=>((user === null || user === void 0 ? void 0 : user.role) || "").toLowerCase().includes("company")
    }["DashboardPage.useMemo[isCompany]"], [
        user
    ]);
    const [createOpen, setCreateOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [jobs, setJobs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [editIndex, setEditIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editOpen, setEditOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    function toBackendJobType(label) {
        if (!label) return undefined;
        const t = label.replace(/\s+/g, '').toLowerCase();
        if (t.includes('fulltime')) return 'FullTime';
        if (t.includes('parttime')) return 'PartTime';
        if (t.includes('intern')) return 'Internship';
        if (t.includes('contract')) return 'Contract';
        if ([
            'FullTime',
            'PartTime',
            'Internship',
            'Contract'
        ].includes(label)) return label;
        return undefined;
    }
    // ---------------------------
    // GET: load jobs
    // ---------------------------
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DashboardPage.useEffect": ()=>{
            if (!isReady) return; // wait for auth
            if (!isCompany) {
                // Not authorized: route away
                router.replace("/");
                return;
            }
            const load = {
                "DashboardPage.useEffect.load": async ()=>{
                    setLoading(true);
                    try {
                        // Backend defines GET all at /api/company/job-postings/all
                        const headers = (user === null || user === void 0 ? void 0 : user.access_token) ? {
                            Authorization: "Bearer ".concat(user.access_token)
                        } : {};
                        const data = await fetchAuthedJson(API_URL_GET_ALL, {
                            method: "GET",
                            headers
                        });
                        setJobs(data.data || data || []);
                    } catch (err) {
                        console.error("Failed to fetch jobs:", err);
                    } finally{
                        setLoading(false);
                    }
                }
            }["DashboardPage.useEffect.load"];
            load();
        }
    }["DashboardPage.useEffect"], [
        isReady,
        isCompany,
        router
    ]);
    // ---------------------------
    // POST: create job
    // ---------------------------
    const handleAddJob = async (job)=>{
        try {
            var _job_minimum_expected_salary, _job_maximum_expected_salary;
            const body = {
                job_title: (job.title || "").trim() || (job.position || "").trim(),
                description: job.details,
                location: job.location || "",
                work_place: job.workType || undefined,
                minimum_expected_salary: (_job_minimum_expected_salary = job.minimum_expected_salary) !== null && _job_minimum_expected_salary !== void 0 ? _job_minimum_expected_salary : undefined,
                maximum_expected_salary: (_job_maximum_expected_salary = job.maximum_expected_salary) !== null && _job_maximum_expected_salary !== void 0 ? _job_maximum_expected_salary : undefined,
                expired_at: job.expired_at || undefined,
                jobType: toBackendJobType(job.jobType),
                position: job.position,
                available_position: job.positionsAvailable
            };
            console.log("[JobPostings] Creating job with payload:", body);
            const headers = {
                "Content-Type": "application/json",
                ...(user === null || user === void 0 ? void 0 : user.access_token) ? {
                    Authorization: "Bearer ".concat(user.access_token)
                } : {}
            };
            const data = await fetchAuthedJson(API_URL_BASE, {
                method: "POST",
                body: JSON.stringify(body),
                headers
            });
            const newJob = data.data || data;
            setJobs((prev)=>[
                    newJob,
                    ...prev
                ]);
            setCreateOpen(false);
        } catch (err) {
            console.error("Failed to add job:", err);
            alert("Failed to add job posting.");
        }
    };
    // ---------------------------
    // PATCH: update job
    // ---------------------------
    const handleSaveEdit = async (updated)=>{
        if (editIndex === null) return;
        const job = jobs[editIndex];
        try {
            var _updated_minimum_expected_salary, _updated_maximum_expected_salary;
            const body = {
                job_title: (updated.title || "").trim() || (updated.position || "").trim(),
                description: updated.details,
                location: updated.location || job.location,
                work_place: updated.workType || job.work_place,
                minimum_expected_salary: (_updated_minimum_expected_salary = updated.minimum_expected_salary) !== null && _updated_minimum_expected_salary !== void 0 ? _updated_minimum_expected_salary : job.minimum_expected_salary,
                maximum_expected_salary: (_updated_maximum_expected_salary = updated.maximum_expected_salary) !== null && _updated_maximum_expected_salary !== void 0 ? _updated_maximum_expected_salary : job.maximum_expected_salary,
                expired_at: updated.expired_at || job.expired_at,
                jobType: toBackendJobType(updated.jobType),
                position: updated.position,
                available_position: updated.positionsAvailable
            };
            console.log("[JobPostings] Updating job id=", job === null || job === void 0 ? void 0 : job.id, "payload:", body);
            const headers = {
                "Content-Type": "application/json",
                ...(user === null || user === void 0 ? void 0 : user.access_token) ? {
                    Authorization: "Bearer ".concat(user.access_token)
                } : {}
            };
            const data = await fetchAuthedJson("".concat(API_URL_BASE, "/").concat(job.id), {
                method: "PATCH",
                headers,
                body: JSON.stringify(body)
            });
            const updatedJob = data.data || data;
            setJobs((prev)=>prev.map((j, i)=>i === editIndex ? updatedJob : j));
            closeEdit();
        } catch (err) {
            console.error("Failed to update job:", err);
            alert("Failed to update job posting.");
        }
    };
    const openEdit = (index)=>{
        setEditIndex(index);
        setEditOpen(true);
    };
    const closeEdit = ()=>{
        setEditOpen(false);
        setEditIndex(null);
    };
    var _jobs_editIndex_job_title, _ref, _jobs_editIndex_position, _jobs_editIndex_jobType, _jobs_editIndex_description, _jobs_editIndex_available_position, _jobs_editIndex_location, _jobs_editIndex_work_place;
    const editInitial = editIndex !== null ? {
        title: (_ref = (_jobs_editIndex_job_title = (_jobs_editIndex = jobs[editIndex]) === null || _jobs_editIndex === void 0 ? void 0 : _jobs_editIndex.job_title) !== null && _jobs_editIndex_job_title !== void 0 ? _jobs_editIndex_job_title : (_jobs_editIndex1 = jobs[editIndex]) === null || _jobs_editIndex1 === void 0 ? void 0 : _jobs_editIndex1.position) !== null && _ref !== void 0 ? _ref : "",
        position: (_jobs_editIndex_position = (_jobs_editIndex2 = jobs[editIndex]) === null || _jobs_editIndex2 === void 0 ? void 0 : _jobs_editIndex2.position) !== null && _jobs_editIndex_position !== void 0 ? _jobs_editIndex_position : "",
        jobType: (_jobs_editIndex_jobType = (_jobs_editIndex3 = jobs[editIndex]) === null || _jobs_editIndex3 === void 0 ? void 0 : _jobs_editIndex3.jobType) !== null && _jobs_editIndex_jobType !== void 0 ? _jobs_editIndex_jobType : "",
        details: (_jobs_editIndex_description = (_jobs_editIndex4 = jobs[editIndex]) === null || _jobs_editIndex4 === void 0 ? void 0 : _jobs_editIndex4.description) !== null && _jobs_editIndex_description !== void 0 ? _jobs_editIndex_description : "",
        positionsAvailable: Number((_jobs_editIndex_available_position = (_jobs_editIndex5 = jobs[editIndex]) === null || _jobs_editIndex5 === void 0 ? void 0 : _jobs_editIndex5.available_position) !== null && _jobs_editIndex_available_position !== void 0 ? _jobs_editIndex_available_position : 1),
        location: (_jobs_editIndex_location = (_jobs_editIndex6 = jobs[editIndex]) === null || _jobs_editIndex6 === void 0 ? void 0 : _jobs_editIndex6.location) !== null && _jobs_editIndex_location !== void 0 ? _jobs_editIndex_location : "",
        minimum_expected_salary: (_jobs_editIndex7 = jobs[editIndex]) === null || _jobs_editIndex7 === void 0 ? void 0 : _jobs_editIndex7.minimum_expected_salary,
        maximum_expected_salary: (_jobs_editIndex8 = jobs[editIndex]) === null || _jobs_editIndex8 === void 0 ? void 0 : _jobs_editIndex8.maximum_expected_salary,
        workType: (_jobs_editIndex_work_place = (_jobs_editIndex9 = jobs[editIndex]) === null || _jobs_editIndex9 === void 0 ? void 0 : _jobs_editIndex9.work_place) !== null && _jobs_editIndex_work_place !== void 0 ? _jobs_editIndex_work_place : "",
        expired_at: ((_jobs_editIndex10 = jobs[editIndex]) === null || _jobs_editIndex10 === void 0 ? void 0 : _jobs_editIndex10.expired_at) ? String(jobs[editIndex].expired_at).slice(0, 10) : ""
    } : null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mx-auto max-w-5xl p-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "mb-4 text-2xl font-bold",
                children: "Job Openings"
            }, void 0, false, {
                fileName: "[project]/src/app/company/jobpostings/page.tsx",
                lineNumber: 179,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>setCreateOpen(true),
                className: "rounded-[30] px-4 py-2 font-semibold text-white",
                style: {
                    backgroundColor: '#5D9252'
                },
                children: "+ Post a Job"
            }, void 0, false, {
                fileName: "[project]/src/app/company/jobpostings/page.tsx",
                lineNumber: 181,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-6 space-y-4",
                children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-500",
                    children: "Loading jobs..."
                }, void 0, false, {
                    fileName: "[project]/src/app/company/jobpostings/page.tsx",
                    lineNumber: 190,
                    columnNumber: 11
                }, this) : jobs.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-500",
                    children: "No job postings yet."
                }, void 0, false, {
                    fileName: "[project]/src/app/company/jobpostings/page.tsx",
                    lineNumber: 192,
                    columnNumber: 11
                }, this) : jobs.map((job, i)=>{
                    var _job_available_position;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "rounded-2xl border justify-center items-center bg-gray-50 p-5 shadow-sm min-h-28 md:min-h-30",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex w-full items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-1 text-xl font-extrabold",
                                            children: job.job_title || job.position || "Untitled"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/company/jobpostings/page.tsx",
                                            lineNumber: 198,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-0.5 text-sm text-gray-700",
                                            children: job.position || "-"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/company/jobpostings/page.tsx",
                                            lineNumber: 201,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-1 text-xs font-semibold tracking-wide text-gray-700",
                                            children: [
                                                (job.jobType || "").toString().toUpperCase() || "FULL TIME",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "mx-2 text-gray-300",
                                                    children: "|"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/company/jobpostings/page.tsx",
                                                    lineNumber: 206,
                                                    columnNumber: 21
                                                }, this),
                                                "Positions: ",
                                                (_job_available_position = job.available_position) !== null && _job_available_position !== void 0 ? _job_available_position : 1
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/company/jobpostings/page.tsx",
                                            lineNumber: 204,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/company/jobpostings/page.tsx",
                                    lineNumber: 197,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm text-gray-800",
                                            children: [
                                                job.location || "REMOTE",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "mx-2 text-gray-300",
                                                    children: "|"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/company/jobpostings/page.tsx",
                                                    lineNumber: 214,
                                                    columnNumber: 21
                                                }, this),
                                                job.country || "THAILAND"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/company/jobpostings/page.tsx",
                                            lineNumber: 212,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>openEdit(i),
                                            className: "rounded-full border px-3 py-1 text-sm font-medium hover:bg-gray-100",
                                            style: {
                                                borderColor: "#5D9252",
                                                color: "#2c4d2a"
                                            },
                                            children: "Edit"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/company/jobpostings/page.tsx",
                                            lineNumber: 217,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/company/jobpostings/page.tsx",
                                    lineNumber: 210,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/company/jobpostings/page.tsx",
                            lineNumber: 196,
                            columnNumber: 15
                        }, this)
                    }, job.id || i, false, {
                        fileName: "[project]/src/app/company/jobpostings/page.tsx",
                        lineNumber: 195,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/app/company/jobpostings/page.tsx",
                lineNumber: 188,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EditJobModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: createOpen,
                onClose: ()=>setCreateOpen(false),
                initial: {
                    title: "",
                    position: "",
                    details: "",
                    positionsAvailable: 1,
                    jobType: "Full Time",
                    location: "",
                    minimum_expected_salary: undefined,
                    maximum_expected_salary: undefined,
                    workType: "",
                    expired_at: ""
                },
                onSave: handleAddJob,
                brandColor: "#5D9252",
                mode: "create"
            }, void 0, false, {
                fileName: "[project]/src/app/company/jobpostings/page.tsx",
                lineNumber: 232,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$EditJobModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: editOpen,
                onClose: closeEdit,
                initial: editInitial,
                onSave: handleSaveEdit,
                brandColor: "#5D9252"
            }, void 0, false, {
                fileName: "[project]/src/app/company/jobpostings/page.tsx",
                lineNumber: 241,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/company/jobpostings/page.tsx",
        lineNumber: 178,
        columnNumber: 5
    }, this);
}
_s(DashboardPage, "7mtQfnL1+jXmD/KPthCSjL1nZLQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"]
    ];
});
_c = DashboardPage;
var _c;
__turbopack_context__.k.register(_c, "DashboardPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_c7b78f32._.js.map