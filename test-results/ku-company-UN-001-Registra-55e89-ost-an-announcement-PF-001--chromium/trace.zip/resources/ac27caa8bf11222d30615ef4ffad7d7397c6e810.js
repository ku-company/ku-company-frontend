(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/api/professorannouncement.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createProfessorAnnouncement",
    ()=>createProfessorAnnouncement,
    "deleteProfessorAnnouncement",
    ()=>deleteProfessorAnnouncement,
    "fetchProfessorAnnouncements",
    ()=>fetchProfessorAnnouncements
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/base.ts [app-client] (ecmascript)");
;
/* -------------------- Base URLs -------------------- */ const RAW_BASE = ("TURBOPACK compile-time value", "http://localhost:8000") || "http://localhost:8000";
const BASE_URL = RAW_BASE.replace(/\/$/, ""); // กัน double slash
const API_URL = "".concat(BASE_URL, "/api/professor/announcements/");
// Public feed endpoint (read-only)
const API_URL_PUBLIC = "".concat(BASE_URL, "/api/announcements");
const API_URL_POSTS = "".concat(BASE_URL, "/api/professor/posts/");
/* -------------------- Helpers -------------------- */ function withAuthHeaders() {
    let init = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    const token = ("TURBOPACK compile-time truthy", 1) ? localStorage.getItem("access_token") : "TURBOPACK unreachable";
    // Default headers + แนบ Bearer ถ้ามี
    const headers = {
        "Content-Type": "application/json",
        ...token ? {
            Authorization: "Bearer ".concat(token)
        } : {}
    };
    // ใช้ cookie session ได้ด้วย (ถ้ามี), ปิด cache กันข้อมูลค้าง
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
        credentials: "include",
        cache: "no-store",
        ...init,
        headers: {
            ...headers,
            ...init.headers || {}
        }
    });
}
async function handleResponse(res, action) {
    const ctype = res.headers.get("content-type") || "";
    const isJson = ctype.includes("application/json");
    const body = isJson ? await res.json().catch(()=>({})) : await res.text();
    if (!res.ok) {
        const message = isJson && ((body === null || body === void 0 ? void 0 : body.message) || (body === null || body === void 0 ? void 0 : body.detail)) || (typeof body === "string" ? body : "");
        const suffix = message ? " - ".concat(message) : "";
        throw new Error("".concat(action, ": ").concat(res.status, " ").concat(res.statusText).concat(suffix));
    }
    return isJson ? body : {};
}
async function fetchProfessorAnnouncements(signal) {
    // Use the public announcements feed so all roles can read
    const res = await fetch(API_URL_PUBLIC, withAuthHeaders({
        method: "GET",
        signal
    }));
    return handleResponse(res, "Failed to fetch announcements");
}
async function createProfessorAnnouncement(data) {
    const res = await fetch(API_URL, withAuthHeaders({
        method: "POST",
        body: JSON.stringify(data)
    }));
    return handleResponse(res, "Failed to create announcement");
}
async function deleteProfessorAnnouncement(id) {
    const res = await fetch("".concat(API_URL_POSTS).concat(id, "/"), withAuthHeaders({
        method: "DELETE"
    }));
    await handleResponse(res, "Failed to delete announcement");
    return true;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/professor-annoucement/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProfessorAnnouncementPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$professorannouncement$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/professorannouncement.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const GREEN = "#5b8f5b";
function ProfessorAnnouncementPage() {
    _s();
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const [announcements, setAnnouncements] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [content, setContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [errorMessage, setErrorMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    /* ---------------- Fetch announcements ---------------- */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProfessorAnnouncementPage.useEffect": ()=>{
            ({
                "ProfessorAnnouncementPage.useEffect": async ()=>{
                    try {
                        const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$professorannouncement$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchProfessorAnnouncements"])();
                        if (Array.isArray(data)) setAnnouncements(data);
                        else if (data === null || data === void 0 ? void 0 : data.results) setAnnouncements(data.results);
                        else if (data === null || data === void 0 ? void 0 : data.data) setAnnouncements(data.data);
                        else setAnnouncements([]);
                        setErrorMessage(null);
                    } catch (err) {
                        console.error("⚠️ Announcement fetch failed:", err);
                        const errStr = String(err || "");
                        if (errStr.includes("verify your account") || errStr.includes("Please verify your account")) {
                            setErrorMessage("Please verify your account to view announcements.");
                        } else if (errStr.includes("401")) {
                            setErrorMessage("Unauthorized — please log in again.");
                        } else if (errStr.includes("403")) {
                            setErrorMessage("Access denied. You are not allowed to view announcements.");
                        } else if (errStr.includes("Failed to fetch")) {
                            setErrorMessage("Cannot connect to the server. Please check your network.");
                        } else {
                            setErrorMessage("Failed to load announcements. Please try again later.");
                        }
                        setAnnouncements([]);
                    }
                }
            })["ProfessorAnnouncementPage.useEffect"]();
        }
    }["ProfessorAnnouncementPage.useEffect"], []);
    const isProfessor = ((user === null || user === void 0 ? void 0 : user.role) || "").toLowerCase().includes("professor");
    const canPost = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProfessorAnnouncementPage.useMemo[canPost]": ()=>isProfessor && content.trim().length > 0
    }["ProfessorAnnouncementPage.useMemo[canPost]"], [
        isProfessor,
        content
    ]);
    /* ---------------- Create new announcement ---------------- */ const handlePost = async ()=>{
        if (!canPost) return;
        try {
            var _newPost_data;
            const newPost = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$professorannouncement$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProfessorAnnouncement"])({
                content,
                is_connection: false
            });
            if (newPost && (newPost.id || (newPost === null || newPost === void 0 ? void 0 : (_newPost_data = newPost.data) === null || _newPost_data === void 0 ? void 0 : _newPost_data.id))) {
                var _newPost_results;
                const created = newPost.id !== undefined ? newPost : newPost.data || ((_newPost_results = newPost.results) === null || _newPost_results === void 0 ? void 0 : _newPost_results[0]);
                setAnnouncements((prev)=>[
                        created,
                        ...prev
                    ]);
            }
            setContent("");
            setErrorMessage(null);
        } catch (err) {
            console.error("⚠️ Failed to create announcement:", err);
            const errStr = String(err);
            if (errStr.includes("Profile not found")) setErrorMessage("Cannot post yet — your Professor profile hasn’t been created.");
            else if (errStr.includes("401")) setErrorMessage("Unauthorized. Please login again.");
            else setErrorMessage("Failed to create announcement. Try again.");
        }
    };
    /* ---------------- Delete announcement ---------------- */ const handleDelete = async (id)=>{
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$professorannouncement$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteProfessorAnnouncement"])(id);
            setAnnouncements((prev)=>prev.filter((a)=>a.id !== id));
            setErrorMessage(null);
        } catch (err) {
            console.error("❌ Failed to delete:", err);
            setErrorMessage("Failed to delete announcement. Try again.");
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "mt-24 mx-auto max-w-2xl px-4 py-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-2xl font-extrabold tracking-tight text-gray-800 text-center",
                children: "Professor Announcements"
            }, void 0, false, {
                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                lineNumber: 104,
                columnNumber: 7
            }, this),
            errorMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 rounded-lg bg-red-100 border border-red-300 text-red-700 p-3 text-sm text-center",
                children: errorMessage
            }, void 0, false, {
                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                lineNumber: 109,
                columnNumber: 9
            }, this),
            isProfessor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "mt-6 rounded-xl border bg-white shadow-sm p-4 space-y-3",
                style: {
                    borderColor: GREEN
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        placeholder: "Share an announcement…",
                        value: content,
                        onChange: (e)=>setContent(e.target.value),
                        className: "w-full h-24 resize-none border rounded-md p-3 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    }, void 0, false, {
                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                        lineNumber: 120,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            disabled: !canPost,
                            onClick: handlePost,
                            className: "rounded-md px-5 py-1.5 text-sm font-semibold text-white disabled:opacity-50",
                            style: {
                                backgroundColor: GREEN
                            },
                            children: "Post"
                        }, void 0, false, {
                            fileName: "[project]/src/app/professor-annoucement/page.tsx",
                            lineNumber: 128,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                        lineNumber: 127,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                lineNumber: 116,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-8 space-y-6",
                children: announcements.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-500 text-sm text-center mt-10",
                    children: "No announcements yet."
                }, void 0, false, {
                    fileName: "[project]/src/app/professor-annoucement/page.tsx",
                    lineNumber: 143,
                    columnNumber: 11
                }, this) : announcements.map((a)=>{
                    var _a_author_username, _a_author, _a_author1;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        className: "rounded-2xl border bg-white shadow-sm p-5 relative",
                        style: {
                            borderColor: GREEN
                        },
                        children: [
                            isProfessor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleDelete(a.id),
                                className: "absolute right-3 top-3 grid h-7 w-7 place-items-center rounded-md border bg-white text-gray-600 hover:bg-gray-100",
                                title: "Delete",
                                children: "✕"
                            }, void 0, false, {
                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                lineNumber: 155,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3 mb-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-8 w-8 rounded-full bg-emerald-700 text-white grid place-items-center font-semibold",
                                        children: (((_a_author = a.author) === null || _a_author === void 0 ? void 0 : (_a_author_username = _a_author.username) === null || _a_author_username === void 0 ? void 0 : _a_author_username[0]) || "P").toUpperCase()
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                        lineNumber: 166,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-semibold text-sm text-gray-800",
                                                children: ((_a_author1 = a.author) === null || _a_author1 === void 0 ? void 0 : _a_author1.username) || "Professor"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                lineNumber: 170,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-xs text-gray-500",
                                                children: new Date(a.created_at).toLocaleString()
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                lineNumber: 173,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                        lineNumber: 169,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                lineNumber: 165,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-gray-700 text-sm leading-6 whitespace-pre-line",
                                children: a.content
                            }, void 0, false, {
                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                lineNumber: 180,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-4 flex items-center gap-6 text-sm text-gray-600",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1 cursor-pointer",
                                        children: [
                                            "💚 ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "41"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                lineNumber: 187,
                                                columnNumber: 22
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                        lineNumber: 186,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1 cursor-pointer",
                                        children: [
                                            "💬 ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "3"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                lineNumber: 190,
                                                columnNumber: 22
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                        lineNumber: 189,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "flex items-center gap-1 cursor-pointer",
                                        children: [
                                            "🔄 ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "52"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                lineNumber: 193,
                                                columnNumber: 22
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                        lineNumber: 192,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                lineNumber: 185,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-3 border-t pt-3 space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "h-6 w-6 rounded-full bg-gray-200"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                lineNumber: 200,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                placeholder: "Add a comment...",
                                                className: "flex-1 border rounded-full px-3 py-1 text-sm focus:outline-none"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                lineNumber: 201,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                        lineNumber: 199,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-2 text-sm text-gray-800 mt-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                                        children: "Jetaime_op"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                        lineNumber: 210,
                                                        columnNumber: 21
                                                    }, this),
                                                    " ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-gray-500 text-xs",
                                                        children: "· Dec 23, 2023"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                        lineNumber: 211,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: "Amazing"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                        lineNumber: 212,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                lineNumber: 209,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                                        children: "milliebobbybrown"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                        lineNumber: 215,
                                                        columnNumber: 21
                                                    }, this),
                                                    " ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-gray-500 text-xs",
                                                        children: "· Jan 02, 2024"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                        lineNumber: 216,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: "Interesting"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                        lineNumber: 217,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                lineNumber: 214,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                                        children: "junior.np"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                        lineNumber: 220,
                                                        columnNumber: 21
                                                    }, this),
                                                    " ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-gray-500 text-xs",
                                                        children: "· Jan 15, 2024"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                        lineNumber: 221,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: "good"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                        lineNumber: 222,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                                lineNumber: 219,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                        lineNumber: 208,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                                lineNumber: 198,
                                columnNumber: 15
                            }, this)
                        ]
                    }, a.id, true, {
                        fileName: "[project]/src/app/professor-annoucement/page.tsx",
                        lineNumber: 148,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/app/professor-annoucement/page.tsx",
                lineNumber: 141,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/professor-annoucement/page.tsx",
        lineNumber: 103,
        columnNumber: 5
    }, this);
}
_s(ProfessorAnnouncementPage, "yd7k4Ne/6o7WqMjsyz7n5wf2wVo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"]
    ];
});
_c = ProfessorAnnouncementPage;
var _c;
__turbopack_context__.k.register(_c, "ProfessorAnnouncementPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_20bf3223._.js.map