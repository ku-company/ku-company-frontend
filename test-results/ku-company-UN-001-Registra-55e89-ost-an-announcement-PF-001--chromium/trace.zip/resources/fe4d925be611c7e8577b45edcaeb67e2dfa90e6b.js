(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/api/logout.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "logoutServerSession",
    ()=>logoutServerSession
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var _process_env_NEXT_PUBLIC_API_BASE_URL;
const API_BASE = ((_process_env_NEXT_PUBLIC_API_BASE_URL = ("TURBOPACK compile-time value", "http://localhost:8000")) === null || _process_env_NEXT_PUBLIC_API_BASE_URL === void 0 ? void 0 : _process_env_NEXT_PUBLIC_API_BASE_URL.replace(/\/+$/, "")) || "http://localhost:8000";
async function logoutServerSession() {
    try {
        const res = await fetch("".concat(API_BASE, "/api/user/logout"), {
            method: "GET",
            credentials: "include"
        });
        if (!res.ok) {
            console.warn("Logout failed:", await res.text());
        }
    } catch (err) {
        console.error("Logout error:", err);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/AuthContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$logout$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/logout.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function normalizeRole(r) {
    const raw = (r !== null && r !== void 0 ? r : "").trim().toLowerCase();
    if (raw.includes("company")) return "company";
    if (raw.includes("student")) return "student";
    if (raw.includes("professor")) return "professor";
    return raw;
}
function AuthProvider(param) {
    let { children } = param;
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isReady, setIsReady] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const expTimerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            const token = localStorage.getItem("access_token");
            var _localStorage_getItem;
            const user_name = (_localStorage_getItem = localStorage.getItem("user_name")) !== null && _localStorage_getItem !== void 0 ? _localStorage_getItem : "";
            var _localStorage_getItem1;
            const email = (_localStorage_getItem1 = localStorage.getItem("email")) !== null && _localStorage_getItem1 !== void 0 ? _localStorage_getItem1 : "";
            var _localStorage_getItem2;
            const role = (_localStorage_getItem2 = localStorage.getItem("role")) !== null && _localStorage_getItem2 !== void 0 ? _localStorage_getItem2 : "";
            // Consider user authenticated if an access token exists; fill other fields if present
            if (token) {
                setUser({
                    user_name,
                    email,
                    role: normalizeRole(role),
                    access_token: token
                });
            }
            setIsReady(true);
        }
    }["AuthProvider.useEffect"], []);
    // Auto-logout on JWT expiry or 15 minutes after login (hard cap)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            function decodeExp(t) {
                if (!t) return null;
                try {
                    const base64 = t.split('.')[1];
                    if (!base64) return null;
                    const json = atob(base64.replace(/-/g, '+').replace(/_/g, '/'));
                    const payload = JSON.parse(json);
                    return typeof (payload === null || payload === void 0 ? void 0 : payload.exp) === 'number' ? payload.exp : null;
                } catch (e) {
                    return null;
                }
            }
            // Clear any previous timer
            if (expTimerRef.current) {
                window.clearTimeout(expTimerRef.current);
                expTimerRef.current = null;
            }
            const token = localStorage.getItem('access_token');
            const expSec = decodeExp(token);
            const now = Date.now();
            const fifteenMinMs = 15 * 60 * 1000;
            const expMs = expSec ? expSec * 1000 : now + fifteenMinMs;
            // If exp appears later than 15 minutes, still enforce 15 minutes cap
            const fireAt = Math.min(expMs, now + fifteenMinMs);
            const delay = Math.max(0, fireAt - now);
            expTimerRef.current = window.setTimeout({
                "AuthProvider.useEffect": async ()=>{
                    try {
                        const { autoLogout, shouldDeferAutoLogout } = await __turbopack_context__.A("[project]/src/utils/httpError.ts [app-client] (ecmascript, async loader)");
                        if (!shouldDeferAutoLogout()) autoLogout();
                    } catch (e) {}
                }
            }["AuthProvider.useEffect"], delay);
            return ({
                "AuthProvider.useEffect": ()=>{
                    if (expTimerRef.current) {
                        window.clearTimeout(expTimerRef.current);
                        expTimerRef.current = null;
                    }
                }
            })["AuthProvider.useEffect"];
        }
    }["AuthProvider.useEffect"], [
        user === null || user === void 0 ? void 0 : user.access_token
    ]);
    function login(data) {
        var _data_roles, _ref;
        const role = normalizeRole((_ref = (_data_roles = data.roles) !== null && _data_roles !== void 0 ? _data_roles : data.role) !== null && _ref !== void 0 ? _ref : "");
        var _data_access_token;
        localStorage.setItem("access_token", (_data_access_token = data.access_token) !== null && _data_access_token !== void 0 ? _data_access_token : "");
        var _data_refresh_token;
        localStorage.setItem("refresh_token", (_data_refresh_token = data.refresh_token) !== null && _data_refresh_token !== void 0 ? _data_refresh_token : "");
        var _data_user_name;
        localStorage.setItem("user_name", (_data_user_name = data.user_name) !== null && _data_user_name !== void 0 ? _data_user_name : "");
        var _data_email;
        localStorage.setItem("email", (_data_email = data.email) !== null && _data_email !== void 0 ? _data_email : "");
        localStorage.setItem("role", role);
        var _data_user_name1, _data_email1;
        setUser({
            user_name: (_data_user_name1 = data.user_name) !== null && _data_user_name1 !== void 0 ? _data_user_name1 : "",
            email: (_data_email1 = data.email) !== null && _data_email1 !== void 0 ? _data_email1 : "",
            role,
            access_token: data.access_token,
            refresh_token: data.refresh_token
        });
    }
    function logout() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$logout$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logoutServerSession"])();
        localStorage.clear();
        setUser(null);
        if ("TURBOPACK compile-time truthy", 1) {
            var _window_location;
            const path = ((_window_location = window.location) === null || _window_location === void 0 ? void 0 : _window_location.pathname) || '';
            if (!path.startsWith('/login')) window.location.href = '/login';
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            user,
            isReady,
            login,
            logout
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/AuthContext.tsx",
        lineNumber: 130,
        columnNumber: 5
    }, this);
}
_s(AuthProvider, "kq7PRl3IHzZFSSXEu5vlqLhOtms=");
_c = AuthProvider;
function useAuth() {
    _s1();
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
    return ctx;
}
_s1(useAuth, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/api/session.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchAuthMe",
    ()=>fetchAuthMe,
    "normalizeRole",
    ()=>normalizeRole
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var _process_env_NEXT_PUBLIC_API_BASE_URL;
const API_BASE = ((_process_env_NEXT_PUBLIC_API_BASE_URL = ("TURBOPACK compile-time value", "http://localhost:8000")) === null || _process_env_NEXT_PUBLIC_API_BASE_URL === void 0 ? void 0 : _process_env_NEXT_PUBLIC_API_BASE_URL.replace(/\/+$/, "")) || "http://localhost:8000";
// Unwraps { message, data } or returns raw
function unwrap(p) {
    return p && typeof p === "object" && "data" in p && p.data ? p.data : p;
}
async function fetchAuthMe() {
    try {
        const token = localStorage.getItem("access_token");
        console.log("🔸 fetchAuthMe() called, token =", token ? "found" : "missing");
        const res = await fetch("".concat(API_BASE, "/api/auth/me"), {
            method: "GET",
            credentials: "include",
            headers: {
                "Content-Type": "application/json",
                ...token ? {
                    Authorization: "Bearer ".concat(token)
                } : {}
            }
        });
        console.log("🔸 /auth/me response status:", res.status);
        // Gracefully handle unauthenticated states (401/403) or any non-OK
        if (!res.ok) {
            const text = await res.text().catch(()=>"");
            // Keep this a warn to avoid noisy errors when logged out
            console.warn("⚠️ fetchAuthMe failed:", res.status, text || "(no body)");
            return null;
        }
        const json = await res.json().catch(()=>({}));
        console.log("🟢 fetchAuthMe JSON:", json);
        return unwrap(json);
    } catch (err) {
        // Network errors, CORS issues, or fetch being unavailable
        console.warn("⚠️ fetchAuthMe error (treated as logged out):", err);
        return null;
    }
}
function normalizeRole(r) {
    const raw = (r !== null && r !== void 0 ? r : "").trim().toLowerCase();
    if (raw.includes("company")) return "company";
    if (raw.includes("student")) return "student";
    if (raw.includes("professor")) return "professor";
    return raw;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/api/oauth.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/api/oauth.ts
__turbopack_context__.s([
    "buildGoogleSignupUrl",
    ()=>buildGoogleSignupUrl,
    "parseTokensFromLocation",
    ()=>parseTokensFromLocation,
    "stripTokensFromUrl",
    ()=>stripTokensFromUrl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var _process_env_NEXT_PUBLIC_API_BASE_URL;
const API_BASE = ((_process_env_NEXT_PUBLIC_API_BASE_URL = ("TURBOPACK compile-time value", "http://localhost:8000")) === null || _process_env_NEXT_PUBLIC_API_BASE_URL === void 0 ? void 0 : _process_env_NEXT_PUBLIC_API_BASE_URL.replace(/\/+$/, "")) || "http://localhost:8000";
function buildGoogleSignupUrl() {
    let role = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "Student";
    const url = new URL("".concat(API_BASE, "/api/auth/google?role=Student"));
    url.searchParams.set("role", role);
    return url.toString();
}
function parseTokensFromLocation() {
    let loc = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : window.location;
    const result = {};
    const fromSearch = new URLSearchParams(loc.search);
    const fromHash = new URLSearchParams(loc.hash.replace(/^#/, ""));
    const get = (k)=>{
        var _fromSearch_get, _ref;
        return (_ref = (_fromSearch_get = fromSearch.get(k)) !== null && _fromSearch_get !== void 0 ? _fromSearch_get : fromHash.get(k)) !== null && _ref !== void 0 ? _ref : undefined;
    };
    var _get;
    result.access_token = (_get = get("access_token")) !== null && _get !== void 0 ? _get : undefined;
    var _get1;
    result.refresh_token = (_get1 = get("refresh_token")) !== null && _get1 !== void 0 ? _get1 : undefined;
    var _get2;
    result.user_name = (_get2 = get("user_name")) !== null && _get2 !== void 0 ? _get2 : undefined;
    var _get3;
    result.email = (_get3 = get("email")) !== null && _get3 !== void 0 ? _get3 : undefined;
    var _get4, _ref;
    const rawRole = (_ref = (_get4 = get("roles")) !== null && _get4 !== void 0 ? _get4 : get("role")) !== null && _ref !== void 0 ? _ref : undefined;
    if (rawRole) {
        const r = rawRole.trim().toLowerCase();
        result.role = r.includes("company") ? "Company" : r.includes("student") ? "Student" : rawRole;
    }
    return result;
}
function stripTokensFromUrl() {
    const { origin, pathname } = window.location;
    window.history.replaceState({}, "", "".concat(origin).concat(pathname));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/api/base.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "API_BASE",
    ()=>API_BASE,
    "buildInit",
    ()=>buildInit,
    "getAuthHeaders",
    ()=>getAuthHeaders,
    "unwrap",
    ()=>unwrap
]);
const API_BASE = "http://localhost:8000";
function getAuthHeaders() {
    const token = ("TURBOPACK compile-time truthy", 1) ? localStorage.getItem("access_token") : "TURBOPACK unreachable";
    return token ? {
        Authorization: "Bearer ".concat(token)
    } : {};
}
function buildInit() {
    let init = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    var _init_credentials;
    return {
        // Always include cookies for auth-backed endpoints
        credentials: (_init_credentials = init.credentials) !== null && _init_credentials !== void 0 ? _init_credentials : "include",
        headers: {
            "Content-Type": "application/json",
            ...getAuthHeaders(),
            ...init.headers || {}
        },
        ...init
    };
}
function unwrap(json) {
    if (!json) return {};
    var _json_data;
    return (_json_data = json.data) !== null && _json_data !== void 0 ? _json_data : json;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/httpError.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "assertOk",
    ()=>assertOk,
    "autoLogout",
    ()=>autoLogout,
    "extractErrorMessage",
    ()=>extractErrorMessage,
    "shouldDeferAutoLogout",
    ()=>shouldDeferAutoLogout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$logout$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/logout.ts [app-client] (ecmascript)");
;
let autoLogoutTriggered = false;
async function autoLogout() {
    if (autoLogoutTriggered) return;
    autoLogoutTriggered = true;
    try {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$logout$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logoutServerSession"])();
    } catch (e) {}
    try {
        if ("TURBOPACK compile-time truthy", 1) {
            var _window_location;
            localStorage.clear();
            const path = ((_window_location = window.location) === null || _window_location === void 0 ? void 0 : _window_location.pathname) || "";
            if (!path.startsWith("/login")) {
                window.location.href = "/login";
            } else {
                // Already on login; force refresh to clear any state
                window.location.reload();
            }
        }
    } finally{
        // allow future triggers after a short delay (avoid storms)
        setTimeout(()=>{
            autoLogoutTriggered = false;
        }, 3000);
    }
}
function shouldDeferAutoLogout() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        var _window_location;
        const path = ((_window_location = window.location) === null || _window_location === void 0 ? void 0 : _window_location.pathname) || "";
        if (path.startsWith("/login")) return true;
        const role = (localStorage.getItem("role") || "").toLowerCase();
        if (!role || role.includes("unknown") || role.includes("unset")) return true;
    } catch (e) {}
    return false;
}
function isExpiredAuthMessage(m) {
    const s = (m || "").toLowerCase();
    return s.includes("jwt expired") || s.includes("token expired") || s.includes("expired token") || s.includes("invalid token") || s.includes("invalid or expired") || s.includes("signature has expired");
}
async function extractErrorMessage(res) {
    const status = res.status;
    let text = "";
    let json = undefined;
    try {
        text = await res.text();
        try {
            json = text ? JSON.parse(text) : undefined;
        } catch (e) {}
    } catch (e) {}
    let msg = json && (json.message || json.error || json.detail || json.msg) || (typeof json === "string" ? json : "");
    if (!msg) {
        // If plain text and not JSON-looking, use it
        const looksJson = /^\s*[\[{]/.test(text);
        if (text && !looksJson) msg = text;
    }
    if (!msg) {
        msg = status >= 500 ? "Server error" : status === 404 ? "Not found" : status === 401 ? "Unauthorized" : status === 403 ? "Forbidden" : status === 400 ? "Bad request" : res.statusText || "Request failed";
    }
    // Auto logout only if clearly expired/invalid auth, not generic 401s
    if (status === 401) {
        const lower = String(msg || text || "").toLowerCase();
        if (isExpiredAuthMessage(lower) && !shouldDeferAutoLogout()) {
            await autoLogout();
        }
    }
    msg = String(msg).trim().replace(/^"|"$/g, "");
    if (msg.length) msg = msg.charAt(0).toUpperCase() + msg.slice(1);
    return msg;
}
async function assertOk(res) {
    if (!res.ok) {
        const message = await extractErrorMessage(res);
        throw new Error(message);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/api/token.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/api/token.ts
__turbopack_context__.s([
    "ensureAccessToken",
    ()=>ensureAccessToken,
    "refreshAccessToken",
    ()=>refreshAccessToken
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/base.ts [app-client] (ecmascript)");
;
async function refreshAccessToken() {
    try {
        const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/user/refresh-token"), {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include"
        });
        const raw = await res.text();
        if (!res.ok) {
            console.warn("refreshAccessToken failed:", res.status, raw);
            return null;
        }
        let json = {};
        try {
            json = JSON.parse(raw);
        } catch (e) {}
        const data = (json === null || json === void 0 ? void 0 : json.data) || json;
        const token = data === null || data === void 0 ? void 0 : data.access_token;
        if (token) {
            localStorage.setItem("access_token", token);
            return token;
        }
        return null;
    } catch (e) {
        console.warn("refreshAccessToken error:", e);
        return null;
    }
}
async function ensureAccessToken() {
    const existing = ("TURBOPACK compile-time truthy", 1) ? localStorage.getItem("access_token") : "TURBOPACK unreachable";
    if (existing && existing.length > 0) return existing;
    return await refreshAccessToken();
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/api/professorprofile.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/api/professorprofile.ts
__turbopack_context__.s([
    "createProfessorProfile",
    ()=>createProfessorProfile,
    "getMyProfessorProfile",
    ()=>getMyProfessorProfile,
    "patchProfessorProfile",
    ()=>patchProfessorProfile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/base.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/httpError.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$token$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/token.ts [app-client] (ecmascript)");
;
;
;
async function getMyProfessorProfile(signal) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$token$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureAccessToken"])();
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/professor/my-profile"), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
        signal
    }));
    if (!res.ok) {
        // Service returns 400 with message "Profile not found" when absent
        const text = await res.text().catch(()=>"");
        if (res.status === 404 || /profile not found/i.test(text)) return null;
        throw new Error(text || await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(res));
    }
    const json = await res.json().catch(()=>({}));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unwrap"])(json);
}
async function createProfessorProfile(payload) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$token$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureAccessToken"])();
    console.log("[createProfessorProfile] Payload:", payload);
    const secret = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_INTERNAL_SECRET || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_PROFESSOR_SECRET;
    var _localStorage_getItem;
    const token = ("TURBOPACK compile-time truthy", 1) ? (_localStorage_getItem = localStorage.getItem("access_token")) !== null && _localStorage_getItem !== void 0 ? _localStorage_getItem : "" : "TURBOPACK unreachable";
    const headers = {
        "Content-Type": "application/json",
        ...token ? {
            Authorization: "Bearer ".concat(token)
        } : {},
        ...secret ? {
            "x-internal-secret": secret
        } : {}
    };
    const src = payload !== null && payload !== void 0 ? payload : {};
    var _src_department;
    const dept = typeof src.department === "string" ? src.department.trim() : String((_src_department = src.department) !== null && _src_department !== void 0 ? _src_department : "").trim();
    var _src_faculty;
    const fac = typeof src.faculty === "string" ? src.faculty.trim() : String((_src_faculty = src.faculty) !== null && _src_faculty !== void 0 ? _src_faculty : "").trim();
    // Build the exact JSON body the server expects
    const bodyJson = JSON.stringify({
        department: dept,
        faculty: fac
    });
    // Debug log for troubleshooting payload issues (show actual JSON string)
    try {
        console.log("[createProfessorProfile][DEBUG] URL:", "".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/professor/my-profile"));
        console.log("[createProfessorProfile][DEBUG] Method:", "POST");
        console.log("[createProfessorProfile][DEBUG] Headers:", headers);
        console.log("[createProfessorProfile][DEBUG] Body:", bodyJson);
        // Expose on window for inspection if console logs are not visible
        if ("TURBOPACK compile-time truthy", 1) {
            window.__profPostDebug = {
                url: "".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/professor/my-profile"),
                method: "POST",
                headers,
                token,
                body: bodyJson
            };
        }
    } catch (e) {}
    if (!dept || !fac) {
        try {
            console.warn("[createProfessorProfile] Missing required fields:", {
                department: dept,
                faculty: fac
            });
        } catch (e) {}
    }
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/professor/my-profile"), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
        method: "POST",
        headers,
        body: bodyJson
    }));
    // Log raw response for debugging
    try {
        const preview = await res.clone().text();
        console.log("[createProfessorProfile][DEBUG] Response status:", res.status);
        console.log("[createProfessorProfile][DEBUG] Response text:", preview);
        if ("TURBOPACK compile-time truthy", 1) {
            window.__profPostRespDebug = {
                status: res.status,
                text: preview
            };
        }
    } catch (e) {}
    if (!res.ok) {
        const text = await res.text().catch(()=>"");
        try {
            console.warn("[createProfessorProfile] Server error:", res.status, text);
        } catch (e) {}
        // If profile already exists, fetch and return it to make callers resilient to races
        if (res.status === 400 && /already exists/i.test(text)) {
            try {
                const existing = await getMyProfessorProfile();
                if (existing) return existing;
            } catch (e) {}
        }
        throw new Error(text || await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(res));
    }
    const json = await res.json().catch(()=>({}));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unwrap"])(json);
}
async function patchProfessorProfile(updates) {
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$token$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureAccessToken"])();
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/professor/my-profile"), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
        method: "PATCH",
        body: JSON.stringify(updates)
    }));
    if (!res.ok) {
        throw new Error(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(res));
    }
    const json = await res.json().catch(()=>({}));
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unwrap"])(json);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/api/companyprofile.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createCompanyProfile",
    ()=>createCompanyProfile,
    "createDefaultCompanyProfile",
    ()=>createDefaultCompanyProfile,
    "getCompanyProfile",
    ()=>getCompanyProfile,
    "updateCompanyProfile",
    ()=>updateCompanyProfile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/httpError.ts [app-client] (ecmascript)");
var _process_env_NEXT_PUBLIC_API_BASE_URL;
const API_BASE = ((_process_env_NEXT_PUBLIC_API_BASE_URL = ("TURBOPACK compile-time value", "http://localhost:8000")) === null || _process_env_NEXT_PUBLIC_API_BASE_URL === void 0 ? void 0 : _process_env_NEXT_PUBLIC_API_BASE_URL.replace(/\/+$/, "")) || "http://localhost:8000";
function buildInit() {
    let init = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    const token = ("TURBOPACK compile-time truthy", 1) ? localStorage.getItem("access_token") : "TURBOPACK unreachable";
    const headers = {
        "Content-Type": "application/json",
        ...token ? {
            Authorization: "Bearer ".concat(token)
        } : {},
        ...init.headers || {}
    };
    return {
        credentials: "include",
        ...init,
        headers
    };
}
function unwrap(payload) {
    return payload && typeof payload === "object" && "data" in payload && payload.data ? payload.data : payload;
}
async function getCompanyProfile(signal) {
    const res = await fetch("".concat(API_BASE, "/api/company/profile"), buildInit({
        signal
    }));
    if (res.status === 404) return null;
    if (!res.ok) {
        throw new Error(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(res));
    }
    const json = await res.json().catch(()=>({}));
    return unwrap(json);
}
async function createCompanyProfile(payload) {
    const res = await fetch("".concat(API_BASE, "/api/company/profile"), buildInit({
        method: "POST",
        body: JSON.stringify(payload)
    }));
    if (!res.ok) {
        throw new Error(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(res));
    }
    const json = await res.json().catch(()=>({}));
    return unwrap(json);
}
async function createDefaultCompanyProfile(company_name) {
    try {
        const res = await fetch("".concat(API_BASE, "/api/company/profile"), {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include",
            body: JSON.stringify({
                company_name,
                description: "To be Added",
                industry: "",
                tel: "",
                location: "",
                country: ""
            })
        });
        if (!res.ok) {
            throw new Error(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(res));
        }
        return await res.json();
    } catch (err) {
        console.warn("createDefaultCompanyProfile failed:", err);
        return null; // don't crash, continue normal flow
    }
}
async function updateCompanyProfile(payload) {
    const res = await fetch("".concat(API_BASE, "/api/company/profile"), buildInit({
        method: "PATCH",
        body: JSON.stringify(payload)
    }));
    if (!res.ok) {
        throw new Error(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(res));
    }
    const json = await res.json().catch(()=>({}));
    return unwrap(json);
}
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/auth/BootstrapSession.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BootstrapSession
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$session$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/session.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$oauth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/oauth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$professorprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/professorprofile.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$companyprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/companyprofile.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function BootstrapSession() {
    _s();
    const { user, login } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const ran = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BootstrapSession.useEffect": ()=>{
            if (ran.current) return;
            ran.current = true;
            console.log("🟡 BootstrapSession started...");
            ({
                "BootstrapSession.useEffect": async ()=>{
                    try {
                        // 1) Capture OAuth tokens in URL (either ? or #) and store
                        try {
                            const tokens = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$oauth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseTokensFromLocation"])();
                            const fromSearch = new URLSearchParams(window.location.search);
                            const fromHash = new URLSearchParams(window.location.hash.replace(/^#/, ""));
                            const isSignup = fromSearch.get("signup") === "1" || fromHash.get("signup") === "1";
                            if (tokens === null || tokens === void 0 ? void 0 : tokens.access_token) {
                                localStorage.setItem("access_token", tokens.access_token);
                                if (tokens.refresh_token) localStorage.setItem("refresh_token", tokens.refresh_token);
                                if (tokens.user_name) localStorage.setItem("user_name", tokens.user_name);
                                if (tokens.email) localStorage.setItem("email", tokens.email);
                                if (tokens.role) localStorage.setItem("role", tokens.role);
                                // If this OAuth was initiated from a signup flow for Company, mark onboarding
                                try {
                                    var _tokens_role;
                                    const roleNorm = String((_tokens_role = tokens.role) !== null && _tokens_role !== void 0 ? _tokens_role : "").toLowerCase();
                                    const pending = localStorage.getItem("pending_oauth_signup_company") === "1";
                                    if (pending || isSignup && roleNorm.includes("company")) {
                                        localStorage.setItem("needs_company_onboarding", "1");
                                        localStorage.removeItem("pending_oauth_signup_company");
                                    }
                                } catch (e) {}
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$oauth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stripTokensFromUrl"])();
                                console.log("✅ Stored OAuth tokens from URL");
                            }
                        } catch (e) {
                            console.warn("⚠️ Failed to parse OAuth tokens from URL:", e);
                        }
                        // 2) Fetch current user using cookie or newly stored token
                        const me = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$session$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchAuthMe"])();
                        console.log("🟢 fetchAuthMe() returned:", me);
                        if (me && me.user_name) {
                            var _localStorage_getItem, _localStorage_getItem1, _me_email, _me_role, _ref;
                            login({
                                access_token: (_localStorage_getItem = localStorage.getItem("access_token")) !== null && _localStorage_getItem !== void 0 ? _localStorage_getItem : "",
                                refresh_token: (_localStorage_getItem1 = localStorage.getItem("refresh_token")) !== null && _localStorage_getItem1 !== void 0 ? _localStorage_getItem1 : "",
                                user_name: me.user_name,
                                email: (_me_email = me.email) !== null && _me_email !== void 0 ? _me_email : "",
                                role: (_ref = (_me_role = me.role) !== null && _me_role !== void 0 ? _me_role : me.roles) !== null && _ref !== void 0 ? _ref : "student"
                            });
                            var _me_role1;
                            console.log("✅ Logged in as:", (_me_role1 = me.role) !== null && _me_role1 !== void 0 ? _me_role1 : me.roles);
                            // Auto-create professor profile to bypass backend bug
                            try {
                                var _me_role2;
                                const roleNorm = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$session$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeRole"])((_me_role2 = me.role) !== null && _me_role2 !== void 0 ? _me_role2 : me.roles);
                                if (roleNorm === "professor") {
                                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$professorprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProfessorProfile"])({
                                        department: "computer",
                                        faculty: "engineering"
                                    });
                                    console.log("🟢 Professor profile ensured");
                                }
                            } catch (e) {
                                console.warn("⚠️ Skipping professor profile auto-create:", e);
                            }
                            // If OAuth signup was initiated from /register/company but no tokens were present in URL,
                            // ensure we still set the one-time onboarding flag based on the pending marker.
                            try {
                                const pending = localStorage.getItem("pending_oauth_signup_company") === "1";
                                var _me_role3, _ref1;
                                const roleNorm = String((_ref1 = (_me_role3 = me.role) !== null && _me_role3 !== void 0 ? _me_role3 : me.roles) !== null && _ref1 !== void 0 ? _ref1 : "").toLowerCase();
                                if (pending && roleNorm.includes("company")) {
                                    localStorage.setItem("needs_company_onboarding", "1");
                                    localStorage.removeItem("pending_oauth_signup_company");
                                }
                            } catch (e) {}
                            var _me_role4, _ref2;
                            // Keep profile bootstrap if you still want a default profile; does not trigger modal
                            const roleNorm = String((_ref2 = (_me_role4 = me.role) !== null && _me_role4 !== void 0 ? _me_role4 : me.roles) !== null && _ref2 !== void 0 ? _ref2 : "").toLowerCase();
                            if (roleNorm.includes("company")) {
                                try {
                                    const existing = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$companyprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCompanyProfile"])();
                                    if (!existing) {
                                        const name = me.company_name || me.user_name || "";
                                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$companyprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDefaultCompanyProfile"])(name);
                                        console.log("🏢 Ensured default company profile exists");
                                    }
                                } catch (e) {
                                    console.warn("⚠️ Unable to ensure company profile:", e);
                                }
                            }
                        } else {
                            console.warn("⚠️ No user data from fetchAuthMe()");
                        }
                    } catch (err) {
                        console.error("❌ BootstrapSession failed:", err);
                    }
                }
            })["BootstrapSession.useEffect"]();
        }
    }["BootstrapSession.useEffect"], [
        login
    ]);
    return null;
}
_s(BootstrapSession, "C3ihAg7E/4eXL2G156V0HM4aDo4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"]
    ];
});
_c = BootstrapSession;
var _c;
__turbopack_context__.k.register(_c, "BootstrapSession");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/auth/AuthExpiryHandler.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AUTH_EXPIRED_EVENT",
    ()=>AUTH_EXPIRED_EVENT,
    "default",
    ()=>AuthExpiryHandler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/httpError.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const AUTH_EXPIRED_EVENT = "auth:expired";
function AuthExpiryHandler() {
    _s();
    const { logout } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const installed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthExpiryHandler.useEffect": ()=>{
            if (installed.current) return;
            installed.current = true;
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            const w = window;
            // Wrap window.fetch once to detect JWT expiry responses globally
            if (!w.__authFetchWrapped) {
                const originalFetch = window.fetch.bind(window);
                w.__authFetchWrapped = true;
                w.__authFetchOriginal = originalFetch;
                window.fetch = ({
                    "AuthExpiryHandler.useEffect": async function() {
                        for(var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++){
                            args[_key] = arguments[_key];
                        }
                        try {
                            const input = args[0];
                            const init = args[1] || {};
                            var _input_url;
                            const url = typeof input === "string" ? input : (_input_url = input === null || input === void 0 ? void 0 : input.url) !== null && _input_url !== void 0 ? _input_url : "";
                            const method = (init.method || (typeof input !== "string" ? input === null || input === void 0 ? void 0 : input.method : "GET") || "GET").toUpperCase();
                            if (url.includes("/api/professor/my-profile") && method === "POST") {
                                // Normalize headers to a plain object for visibility
                                const hdrs = {};
                                const headersIn = init.headers || (typeof input !== "string" ? input === null || input === void 0 ? void 0 : input.headers : undefined);
                                if (headersIn) {
                                    if (headersIn instanceof Headers) {
                                        headersIn.forEach({
                                            "AuthExpiryHandler.useEffect": (v, k)=>hdrs[k] = v
                                        }["AuthExpiryHandler.useEffect"]);
                                    } else if (Array.isArray(headersIn)) {
                                        for (const [k, v] of headersIn)hdrs[String(k)] = String(v);
                                    } else if (typeof headersIn === "object") {
                                        Object.keys(headersIn).forEach({
                                            "AuthExpiryHandler.useEffect": (k)=>hdrs[k] = headersIn[k]
                                        }["AuthExpiryHandler.useEffect"]);
                                    }
                                }
                                const bodyPreview = typeof init.body === "string" ? init.body : "<non-string body>";
                                console.log("[AUTH WRAP][REQUEST]", {
                                    url,
                                    method,
                                    headers: hdrs,
                                    body: bodyPreview
                                });
                            }
                        } catch (e) {}
                        const res = await originalFetch(...args);
                        try {
                            const status = res.status;
                            const hasToken = !!localStorage.getItem("access_token");
                            if (hasToken && (status === 401 || status === 403)) {
                                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldDeferAutoLogout"])()) return res;
                                // Try to sniff message from body without consuming caller's stream
                                const text = await res.clone().text().catch({
                                    "AuthExpiryHandler.useEffect": ()=>""
                                }["AuthExpiryHandler.useEffect"]);
                                const msg = (text || "").toLowerCase();
                                if (msg.includes("jwt expired") || msg.includes("token expired") || msg.includes("expired token")) {
                                    window.dispatchEvent(new Event(AUTH_EXPIRED_EVENT));
                                }
                            }
                        } catch (e) {
                        // no-op
                        }
                        return res;
                    }
                })["AuthExpiryHandler.useEffect"];
            }
            // When notified, clear auth and route to login
            const onExpired = {
                "AuthExpiryHandler.useEffect.onExpired": ()=>{
                    try {
                        logout();
                    } catch (e) {}
                    try {
                        router.replace("/login");
                    } catch (e) {}
                }
            }["AuthExpiryHandler.useEffect.onExpired"];
            window.addEventListener(AUTH_EXPIRED_EVENT, onExpired);
            return ({
                "AuthExpiryHandler.useEffect": ()=>window.removeEventListener(AUTH_EXPIRED_EVENT, onExpired)
            })["AuthExpiryHandler.useEffect"];
        }
    }["AuthExpiryHandler.useEffect"], [
        logout,
        router
    ]);
    return null;
}
_s(AuthExpiryHandler, "DLt7FxKrTrT0oga6v5L3LJVvRFs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = AuthExpiryHandler;
var _c;
__turbopack_context__.k.register(_c, "AuthExpiryHandler");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/api/profileimage.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/api/profileimage.ts
__turbopack_context__.s([
    "PROFILE_IMAGE_UPDATED_EVENT",
    ()=>PROFILE_IMAGE_UPDATED_EVENT,
    "deleteCompanyProfileImage",
    ()=>deleteCompanyProfileImage,
    "deleteEmployeeProfileImage",
    ()=>deleteEmployeeProfileImage,
    "getCompanyProfileImage",
    ()=>getCompanyProfileImage,
    "getEmployeeProfileImage",
    ()=>getEmployeeProfileImage,
    "patchCompanyProfileImage",
    ()=>patchCompanyProfileImage,
    "patchEmployeeProfileImage",
    ()=>patchEmployeeProfileImage,
    "uploadCompanyProfileImage",
    ()=>uploadCompanyProfileImage,
    "uploadEmployeeProfileImage",
    ()=>uploadEmployeeProfileImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/base.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/httpError.ts [app-client] (ecmascript)");
;
;
async function fetchJSON(url, init) {
    const res = await fetch(url, {
        ...init,
        credentials: "include"
    });
    const text = await res.text();
    let json = null;
    try {
        json = text ? JSON.parse(text) : {};
    } catch (e) {
        json = {};
    }
    if (!res.ok) {
        if (res.status === 401 && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldDeferAutoLogout"])()) {
            const lower = (text || "").toLowerCase();
            if (lower.includes("jwt expired") || lower.includes("token expired") || lower.includes("expired token") || lower.includes("invalid token") || lower.includes("invalid or expired") || lower.includes("signature has expired")) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["autoLogout"])();
            }
        }
        const msg = (json === null || json === void 0 ? void 0 : json.message) || text || "".concat(res.status, " ").concat(res.statusText);
        throw new Error(msg);
    }
    return json;
}
function normalizeImageUrl(u) {
    if (!u) return null;
    // Already absolute
    if (/^https?:\/\//i.test(u)) return u;
    // Ensure single slash join with API_BASE
    const base = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"].replace(/\/+$/, "");
    const path = String(u).startsWith("/") ? u : "/".concat(u);
    return "".concat(base).concat(path);
}
function buildFormData(file) {
    const fd = new FormData();
    fd.append("profile_image", file);
    return fd;
}
async function getEmployeeProfileImage() {
    const json = await fetchJSON("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/profile/image"), {
        method: "GET",
        headers: {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuthHeaders"])()
        }
    });
    return normalizeImageUrl(json === null || json === void 0 ? void 0 : json.profile_image);
}
async function uploadEmployeeProfileImage(file) {
    const fd = buildFormData(file);
    const json = await fetchJSON("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/profile/image"), {
        method: "POST",
        headers: {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuthHeaders"])()
        },
        body: fd
    });
    var _normalizeImageUrl;
    return (_normalizeImageUrl = normalizeImageUrl(json === null || json === void 0 ? void 0 : json.imageUrl)) !== null && _normalizeImageUrl !== void 0 ? _normalizeImageUrl : "";
}
async function patchEmployeeProfileImage(file) {
    const fd = buildFormData(file);
    const json = await fetchJSON("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/profile/image"), {
        method: "PATCH",
        headers: {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuthHeaders"])()
        },
        body: fd
    });
    var _normalizeImageUrl;
    return (_normalizeImageUrl = normalizeImageUrl(json === null || json === void 0 ? void 0 : json.imageUrl)) !== null && _normalizeImageUrl !== void 0 ? _normalizeImageUrl : "";
}
async function deleteEmployeeProfileImage() {
    await fetchJSON("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/profile/image"), {
        method: "DELETE",
        headers: {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuthHeaders"])()
        }
    });
}
async function getCompanyProfileImage() {
    const json = await fetchJSON("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/company/profile/image"), {
        method: "GET",
        headers: {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuthHeaders"])()
        }
    });
    return normalizeImageUrl(json === null || json === void 0 ? void 0 : json.profile_image);
}
async function uploadCompanyProfileImage(file) {
    const fd = buildFormData(file);
    const json = await fetchJSON("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/company/profile/image"), {
        method: "POST",
        headers: {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuthHeaders"])()
        },
        body: fd
    });
    var _normalizeImageUrl;
    return (_normalizeImageUrl = normalizeImageUrl(json === null || json === void 0 ? void 0 : json.imageUrl)) !== null && _normalizeImageUrl !== void 0 ? _normalizeImageUrl : "";
}
async function patchCompanyProfileImage(file) {
    const fd = buildFormData(file);
    const json = await fetchJSON("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/company/profile/image"), {
        method: "PATCH",
        headers: {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuthHeaders"])()
        },
        body: fd
    });
    var _normalizeImageUrl;
    return (_normalizeImageUrl = normalizeImageUrl(json === null || json === void 0 ? void 0 : json.imageUrl)) !== null && _normalizeImageUrl !== void 0 ? _normalizeImageUrl : "";
}
async function deleteCompanyProfileImage() {
    await fetchJSON("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/company/profile/image"), {
        method: "DELETE",
        headers: {
            ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuthHeaders"])()
        }
    });
}
const PROFILE_IMAGE_UPDATED_EVENT = "profile-image-updated";
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/api/studentprofile.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/api/studentprofile.ts
__turbopack_context__.s([
    "getMyStudentProfile",
    ()=>getMyStudentProfile,
    "patchMyStudentProfile",
    ()=>patchMyStudentProfile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/base.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/httpError.ts [app-client] (ecmascript)");
;
;
function toBool(v) {
    if (v === true) return true;
    if (v === 1) return true;
    if (typeof v === "string") {
        const s = v.trim().toLowerCase();
        return s === "true" || s === "1" || s === "yes";
    }
    return false;
}
/** Flattens your backend shape to our StudentProfile model. */ function flattenBackendProfile(json) {
    var _json_data, _ref;
    const data = (_ref = (_json_data = json === null || json === void 0 ? void 0 : json.data) !== null && _json_data !== void 0 ? _json_data : json) !== null && _ref !== void 0 ? _ref : {};
    var _data_user;
    const u = (_data_user = data === null || data === void 0 ? void 0 : data.user) !== null && _data_user !== void 0 ? _data_user : {};
    const verified = toBool(u === null || u === void 0 ? void 0 : u.verified) || toBool(u === null || u === void 0 ? void 0 : u.verify) || toBool(u === null || u === void 0 ? void 0 : u.verified_status);
    var _u_first_name;
    const first_name = (_u_first_name = u === null || u === void 0 ? void 0 : u.first_name) !== null && _u_first_name !== void 0 ? _u_first_name : "";
    var _u_last_name;
    const last_name = (_u_last_name = u === null || u === void 0 ? void 0 : u.last_name) !== null && _u_last_name !== void 0 ? _u_last_name : "";
    const full_name = [
        first_name,
        last_name
    ].filter(Boolean).join(" ").trim() || (u === null || u === void 0 ? void 0 : u.user_name) || "";
    const toText = (v)=>{
        if (v == null) return null;
        if (Array.isArray(v)) return v.filter(Boolean).map(String).join("\n");
        if (typeof v === "string") return v;
        try {
            return String(v);
        } catch (e) {
            return null;
        }
    };
    var _data_id, _u_user_name, _u_email, _data_summary, _ref1, _data_birthDate, _ref2, _data_contactInfo;
    return {
        id: (_data_id = data === null || data === void 0 ? void 0 : data.id) !== null && _data_id !== void 0 ? _data_id : u === null || u === void 0 ? void 0 : u.id,
        user_name: (_u_user_name = u === null || u === void 0 ? void 0 : u.user_name) !== null && _u_user_name !== void 0 ? _u_user_name : "",
        email: (_u_email = u === null || u === void 0 ? void 0 : u.email) !== null && _u_email !== void 0 ? _u_email : "",
        verified,
        first_name,
        last_name,
        full_name,
        avatar_url: (u === null || u === void 0 ? void 0 : u.profile_image) || "",
        bio: (_ref1 = (_data_summary = data === null || data === void 0 ? void 0 : data.summary) !== null && _data_summary !== void 0 ? _data_summary : data === null || data === void 0 ? void 0 : data.bio) !== null && _ref1 !== void 0 ? _ref1 : null,
        birthday: (_ref2 = (_data_birthDate = data === null || data === void 0 ? void 0 : data.birthDate) !== null && _data_birthDate !== void 0 ? _data_birthDate : data === null || data === void 0 ? void 0 : data.birthday) !== null && _ref2 !== void 0 ? _ref2 : null,
        // If your backend later structures contactInfo, map as needed:
        // For now we only keep the raw block inside bio/summary section.
        // phone: data?.contactInfo?.phone ?? null,
        // location: data?.contactInfo?.location ?? null,
        education: toText(data === null || data === void 0 ? void 0 : data.education),
        skills: toText(data === null || data === void 0 ? void 0 : data.skills),
        licenses: toText(data === null || data === void 0 ? void 0 : data.licenses),
        languages: toText(data === null || data === void 0 ? void 0 : data.languages),
        experience: toText(data === null || data === void 0 ? void 0 : data.experience),
        contactInfo: (_data_contactInfo = data === null || data === void 0 ? void 0 : data.contactInfo) !== null && _data_contactInfo !== void 0 ? _data_contactInfo : null
    };
}
async function getMyStudentProfile() {
    const token = localStorage.getItem("access_token") || "";
    const baseInit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
        method: "GET"
    });
    const headers = new Headers(baseInit.headers);
    headers.set("Content-Type", "application/json");
    if (token) headers.set("Authorization", "Bearer ".concat(token));
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/my-profile"), {
        ...baseInit,
        headers,
        credentials: "include"
    });
    const raw = await res.text();
    if (!res.ok) throw new Error(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(res));
    let json = {};
    try {
        json = JSON.parse(raw);
    } catch (e) {}
    return flattenBackendProfile(json);
}
async function patchMyStudentProfile(updates) {
    const token = localStorage.getItem("access_token") || "";
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/my-profile/edit"), {
        method: "PATCH",
        headers: {
            "Content-Type": "application/json",
            ...token ? {
                Authorization: "Bearer ".concat(token)
            } : {}
        },
        body: JSON.stringify(updates),
        credentials: "include"
    });
    const raw = await res.text();
    if (!res.ok) throw new Error(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(res));
    // Some endpoints return the updated profile without nested user; ensure we refetch
    try {
        // Try to parse in case it's already the full shape; if not, ignore
        const json = JSON.parse(raw);
        const flattened = flattenBackendProfile(json);
        // If critical user fields are missing, fall back to full refetch
        if (!flattened.user_name && !flattened.full_name) {
            return await getMyStudentProfile();
        }
        return flattened;
    } catch (e) {
        // On any parse/shape mismatch, refetch a consistent profile shape
        return await getMyStudentProfile();
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/roleselector.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RoleSelectModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
const roles = [
    {
        name: "Student",
        icon: "/icons/student.png",
        href: "/register/student"
    },
    {
        name: "Professor",
        icon: "/icons/professor.png",
        href: "/register/professor"
    },
    {
        name: "Company",
        icon: "/icons/company.png",
        href: "/register/company"
    }
];
function RoleSelectModal(param) {
    let { isOpen, onClose, onSelect, disableClose = false } = param;
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    function handleSelect(role) {
        onClose();
        if (onSelect) {
            // Used for OAuth users who need to pick a role
            onSelect(role);
        } else {
            // Default behavior for signup flow
            router.push("/register/".concat(role));
        }
    }
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50",
        onClick: disableClose ? undefined : onClose,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-3xl p-12 w-full max-w-4xl shadow-2xl relative",
            onClick: (e)=>e.stopPropagation(),
            children: [
                !disableClose && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: onClose,
                    className: "absolute top-5 right-5 text-gray-500 hover:text-gray-800 text-3xl",
                    title: "Close",
                    children: "✕"
                }, void 0, false, {
                    fileName: "[project]/src/components/roleselector.tsx",
                    lineNumber: 46,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-4xl font-bold text-black text-center mb-10",
                    children: "Choose Your Role"
                }, void 0, false, {
                    fileName: "[project]/src/components/roleselector.tsx",
                    lineNumber: 55,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 sm:grid-cols-3 gap-10",
                    children: roles.map((role)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>handleSelect(role.name.toLowerCase()),
                            className: "flex flex-col items-center bg-gray-100 p-10 rounded-2xl hover:shadow-lg transition transform hover:scale-105",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-midgreen-500 text-white rounded-full w-32 h-32 flex items-center justify-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        src: role.icon,
                                        alt: role.name,
                                        className: "w-16 h-18"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/roleselector.tsx",
                                        lineNumber: 67,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/roleselector.tsx",
                                    lineNumber: 66,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "mt-6 text-lg text-black font-semibold",
                                    children: role.name
                                }, void 0, false, {
                                    fileName: "[project]/src/components/roleselector.tsx",
                                    lineNumber: 69,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, role.name, true, {
                            fileName: "[project]/src/components/roleselector.tsx",
                            lineNumber: 61,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/src/components/roleselector.tsx",
                    lineNumber: 59,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/roleselector.tsx",
            lineNumber: 40,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/roleselector.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
_s(RoleSelectModal, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = RoleSelectModal;
var _c;
__turbopack_context__.k.register(_c, "RoleSelectModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/ApplyCartContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ApplyCartProvider",
    ()=>ApplyCartProvider,
    "useApplyCart",
    ()=>useApplyCart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
const Ctx = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const STORAGE_KEY = "apply_cart";
function ApplyCartProvider(param) {
    let { children } = param;
    _s();
    const [items, setItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    // Load from localStorage once
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ApplyCartProvider.useEffect": ()=>{
            try {
                const raw = localStorage.getItem(STORAGE_KEY);
                if (raw) {
                    const parsed = JSON.parse(raw);
                    if (Array.isArray(parsed)) setItems(parsed);
                }
            } catch (e) {}
        }
    }["ApplyCartProvider.useEffect"], []);
    // Persist changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ApplyCartProvider.useEffect": ()=>{
            try {
                localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
            } catch (e) {}
        }
    }["ApplyCartProvider.useEffect"], [
        items
    ]);
    const add = (job)=>{
        setItems((prev)=>prev.some((j)=>j.id === job.id) ? prev : [
                job,
                ...prev
            ]);
    };
    const remove = (jobId)=>{
        setItems((prev)=>prev.filter((j)=>j.id !== jobId));
    };
    const clear = ()=>setItems([]);
    const contains = (jobId)=>items.some((j)=>j.id === jobId);
    const count = items.length;
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ApplyCartProvider.useMemo[value]": ()=>({
                items,
                add,
                remove,
                clear,
                contains,
                count
            })
    }["ApplyCartProvider.useMemo[value]"], [
        items
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Ctx.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/ApplyCartContext.tsx",
        lineNumber: 65,
        columnNumber: 10
    }, this);
}
_s(ApplyCartProvider, "4OFbIgC6IYwbNB9qrBDDCpB/gM8=");
_c = ApplyCartProvider;
function useApplyCart() {
    _s1();
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(Ctx);
    if (!ctx) throw new Error("useApplyCart must be used within ApplyCartProvider");
    return ctx;
}
_s1(useApplyCart, "/dMy7t63NXD4eYACoT93CePwGrg=");
var _c;
__turbopack_context__.k.register(_c, "ApplyCartProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Navbar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Navbar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$profileimage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/profileimage.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$studentprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/studentprofile.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$companyprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/companyprofile.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$roleselector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/roleselector.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$ApplyCartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/ApplyCartContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$DocumentTextIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DocumentTextIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/DocumentTextIcon.js [app-client] (ecmascript) <export default as DocumentTextIcon>");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
function NavItem(param) {
    let { href, label } = param;
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])() || "/";
    // Avoid hydration mismatch by enabling active highlighting only after mount
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NavItem.useEffect": ()=>{
            setMounted(true);
        }
    }["NavItem.useEffect"], []);
    const isActive = mounted && (()=>{
        if (href === "/") {
            // Treat both / and /homepage as HOME
            return pathname === "/" || pathname === "/homepage";
        }
        // Match exact or nested paths under the same section
        return pathname === href || pathname.startsWith(href + "/");
    })();
    const base = "px-3 py-1 rounded-full text-sm transition";
    const className = isActive ? "text-white" : "text-gray-700 hover:bg-gray-100";
    const style = isActive ? {
        backgroundColor: "#5D9252"
    } : undefined; // midgreen
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: href,
        className: "".concat(base, " ").concat(className),
        style: style,
        children: label
    }, void 0, false, {
        fileName: "[project]/src/components/Navbar.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_s(NavItem, "ygNLeJD7ToFGVGrBj1/ShptIEc4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = NavItem;
function Navbar() {
    var _user_role, _user_role1, _user_role2, _user_role3;
    _s1();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { user, logout } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const { count } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$ApplyCartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplyCart"])();
    const [dropdownOpen, setDropdownOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showRoleSelector, setShowRoleSelector] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const menuRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [avatarUrl, setAvatarUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [displayName, setDisplayName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const displayRole = ((user === null || user === void 0 ? void 0 : user.role) || "Unknown").slice(0, 1).toUpperCase() + ((user === null || user === void 0 ? void 0 : user.role) || "Unknown").slice(1);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Navbar.useEffect": ()=>{
            function onDocClick(e) {
                if (!menuRef.current) return;
                if (!menuRef.current.contains(e.target)) setDropdownOpen(false);
            }
            if (dropdownOpen) document.addEventListener("mousedown", onDocClick);
            return ({
                "Navbar.useEffect": ()=>document.removeEventListener("mousedown", onDocClick)
            })["Navbar.useEffect"];
        }
    }["Navbar.useEffect"], [
        dropdownOpen
    ]);
    // Load profile image and display name
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Navbar.useEffect": ()=>{
            let cancelled = false;
            const controller = new AbortController();
            const safeUrl = {
                "Navbar.useEffect.safeUrl": (u)=>{
                    if (!u) return null;
                    try {
                        const url = new URL(u, ("TURBOPACK compile-time truthy", 1) ? window.location.origin : "TURBOPACK unreachable");
                        const qp = url.searchParams;
                        const isAwsSigned = qp.has("X-Amz-Algorithm") || qp.has("X-Amz-Signature");
                        if (isAwsSigned) return url.toString();
                        return url.toString();
                    } catch (e) {
                        return u;
                    }
                }
            }["Navbar.useEffect.safeUrl"];
            function roleKnown(r) {
                const raw = (r || '').toLowerCase();
                return raw.includes('student') || raw.includes('company') || raw.includes('professor');
            }
            async function load() {
                if (!user) {
                    setAvatarUrl(null);
                    return;
                }
                if (!roleKnown(user.role)) {
                    // Defer fetching until role is chosen to avoid 401s that would auto-logout
                    setAvatarUrl(null);
                    setDisplayName(user.user_name || '');
                    return;
                }
                try {
                    const role = (user.role || "").toLowerCase();
                    const raw = role.includes("company") ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$profileimage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCompanyProfileImage"])() : await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$profileimage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getEmployeeProfileImage"])();
                    if (!cancelled) setAvatarUrl(safeUrl(raw));
                } catch (e) {
                    if (!cancelled) setAvatarUrl(null);
                }
                // Display name
                try {
                    const role = (user.role || "").toLowerCase();
                    if (role.includes("company")) {
                        const company = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$companyprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCompanyProfile"])(controller.signal);
                        if (!cancelled && (company === null || company === void 0 ? void 0 : company.company_name)) setDisplayName(company.company_name);
                    } else {
                        const student = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$studentprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMyStudentProfile"])();
                        const name = student.full_name || student.user_name || "";
                        if (!cancelled && name) setDisplayName(name);
                    }
                } catch (e) {
                    if (!cancelled) setDisplayName(user.user_name);
                }
            }
            load();
            const onUpdated = {
                "Navbar.useEffect.onUpdated": (e)=>{
                    var _e_detail;
                    const u = e === null || e === void 0 ? void 0 : (_e_detail = e.detail) === null || _e_detail === void 0 ? void 0 : _e_detail.url;
                    if (u) setAvatarUrl(safeUrl(u));
                }
            }["Navbar.useEffect.onUpdated"];
            window.addEventListener(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$profileimage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFILE_IMAGE_UPDATED_EVENT"], onUpdated);
            return ({
                "Navbar.useEffect": ()=>{
                    cancelled = true;
                    controller.abort();
                    window.removeEventListener(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$profileimage$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PROFILE_IMAGE_UPDATED_EVENT"], onUpdated);
                }
            })["Navbar.useEffect"];
        }
    }["Navbar.useEffect"], [
        user
    ]);
    function handleLogout() {
        logout();
        setDropdownOpen(false);
        router.push("/login");
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "sticky top-0 z-40 bg-white/80 backdrop-blur border-b",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mx-auto max-w-7xl h-14 px-4 sm:px-6 lg:px-8 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/",
                            className: "font-semibold tracking-widest",
                            children: "KU-COMPANY"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Navbar.tsx",
                            lineNumber: 134,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "hidden md:block",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                placeholder: "SEARCH",
                                className: "h-9 w-64 rounded-full border px-4 text-sm focus:outline-none focus:ring"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Navbar.tsx",
                                lineNumber: 139,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Navbar.tsx",
                            lineNumber: 138,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                            className: "hidden md:flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavItem, {
                                    href: "/",
                                    label: "HOME"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Navbar.tsx",
                                    lineNumber: 146,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavItem, {
                                    href: "/find-job",
                                    label: "FIND JOB"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Navbar.tsx",
                                    lineNumber: 147,
                                    columnNumber: 13
                                }, this),
                                (user === null || user === void 0 ? void 0 : (_user_role = user.role) === null || _user_role === void 0 ? void 0 : _user_role.toLowerCase().includes("company")) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavItem, {
                                            href: "/company/jobpostings",
                                            label: "JOB POSTINGS"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Navbar.tsx",
                                            lineNumber: 150,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavItem, {
                                            href: "/view-resume",
                                            label: "VIEW RESUME"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Navbar.tsx",
                                            lineNumber: 151,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavItem, {
                                    href: "/professor-annoucement",
                                    label: "ANNOUNCEMENT"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Navbar.tsx",
                                    lineNumber: 154,
                                    columnNumber: 13
                                }, this),
                                (user === null || user === void 0 ? void 0 : (_user_role1 = user.role) === null || _user_role1 === void 0 ? void 0 : _user_role1.toLowerCase().includes("student")) || (user === null || user === void 0 ? void 0 : (_user_role2 = user.role) === null || _user_role2 === void 0 ? void 0 : _user_role2.toLowerCase().includes("alumni")) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavItem, {
                                    href: "/status",
                                    label: "STATUS"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Navbar.tsx",
                                    lineNumber: 156,
                                    columnNumber: 15
                                }, this) : null
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Navbar.tsx",
                            lineNumber: 145,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative flex items-center gap-2",
                            ref: menuRef,
                            children: user ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    (user === null || user === void 0 ? void 0 : (_user_role3 = user.role) === null || _user_role3 === void 0 ? void 0 : _user_role3.toLowerCase().includes("student")) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/apply-list",
                                        className: "relative inline-flex items-center justify-center w-9 h-9 rounded-full hover:bg-gray-100",
                                        "aria-label": "Apply list",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$DocumentTextIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DocumentTextIcon$3e$__["DocumentTextIcon"], {
                                                className: "h-5 w-5 text-gray-700",
                                                "aria-hidden": "true"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Navbar.tsx",
                                                lineNumber: 170,
                                                columnNumber: 21
                                            }, this),
                                            count > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "absolute -top-1 -right-1 inline-flex items-center justify-center rounded-full bg-red-600 text-white text-[10px] w-4 h-4",
                                                children: count
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Navbar.tsx",
                                                lineNumber: 172,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Navbar.tsx",
                                        lineNumber: 165,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "hidden sm:inline-flex items-center rounded-full border px-2 py-0.5 text-xs text-gray-700",
                                        children: displayRole
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Navbar.tsx",
                                        lineNumber: 180,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "w-9 h-9 rounded-full bg-gray-300 overflow-hidden",
                                        onClick: ()=>setDropdownOpen((v)=>!v),
                                        "aria-haspopup": "menu",
                                        "aria-expanded": dropdownOpen ? "true" : "false",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: avatarUrl || "/icons/default-profile.png",
                                            alt: "".concat(displayName || user.user_name, " avatar"),
                                            className: "w-full h-full object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Navbar.tsx",
                                            lineNumber: 188,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Navbar.tsx",
                                        lineNumber: 182,
                                        columnNumber: 17
                                    }, this),
                                    dropdownOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        role: "menu",
                                        className: "absolute right-0 top-12 w-48 bg-white border rounded-lg shadow-lg py-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "px-4 pb-2 text-xs text-gray-500",
                                                children: [
                                                    "Signed in as ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-medium",
                                                        children: displayName || user.user_name
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Navbar.tsx",
                                                        lineNumber: 197,
                                                        columnNumber: 83
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            "Role: ",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "font-medium",
                                                                children: displayRole
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/Navbar.tsx",
                                                                lineNumber: 198,
                                                                columnNumber: 34
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/Navbar.tsx",
                                                        lineNumber: 198,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Navbar.tsx",
                                                lineNumber: 197,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/profile",
                                                onClick: ()=>setDropdownOpen(false),
                                                className: "block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100",
                                                role: "menuitem",
                                                children: "Profile"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Navbar.tsx",
                                                lineNumber: 199,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: handleLogout,
                                                className: "w-full text-left block px-4 py-2 text-sm text-red-600 hover:bg-gray-100",
                                                role: "menuitem",
                                                children: "Logout"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Navbar.tsx",
                                                lineNumber: 207,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Navbar.tsx",
                                        lineNumber: 196,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/login",
                                        className: "text-xs px-3 py-1 rounded border",
                                        children: "LOGIN"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Navbar.tsx",
                                        lineNumber: 219,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setShowRoleSelector(true),
                                        className: "text-xs px-3 py-1 rounded border",
                                        children: "SIGNUP"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Navbar.tsx",
                                        lineNumber: 222,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true)
                        }, void 0, false, {
                            fileName: "[project]/src/components/Navbar.tsx",
                            lineNumber: 160,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Navbar.tsx",
                    lineNumber: 133,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Navbar.tsx",
                lineNumber: 132,
                columnNumber: 7
            }, this),
            showRoleSelector && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 bg-black/50 flex items-center justify-center z-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white p-6 rounded-xl shadow-lg max-w-md w-full",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$roleselector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        isOpen: showRoleSelector,
                        onClose: ()=>setShowRoleSelector(false)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Navbar.tsx",
                        lineNumber: 237,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Navbar.tsx",
                    lineNumber: 236,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Navbar.tsx",
                lineNumber: 235,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s1(Navbar, "kNT1LHuimT+5ZtK5oTTIizzPk0s=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$ApplyCartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplyCart"]
    ];
});
_c1 = Navbar;
var _c, _c1;
__turbopack_context__.k.register(_c, "NavItem");
__turbopack_context__.k.register(_c1, "Navbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/LoginPromptModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LoginPromptModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function LoginPromptModal(param) {
    let { isOpen } = param;
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[200] flex items-center justify-center bg-black/40 p-4",
        role: "dialog",
        "aria-modal": "true",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-sm rounded-2xl bg-white shadow-xl p-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-lg font-semibold",
                    children: "Login Required"
                }, void 0, false, {
                    fileName: "[project]/src/components/LoginPromptModal.tsx",
                    lineNumber: 12,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-2 text-sm text-gray-600",
                    children: "You need to log in to continue."
                }, void 0, false, {
                    fileName: "[project]/src/components/LoginPromptModal.tsx",
                    lineNumber: 13,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-4 flex justify-end gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>router.push("/homepage"),
                            className: "rounded-full border px-4 py-2 text-sm hover:bg-gray-50",
                            children: "Back to homepage"
                        }, void 0, false, {
                            fileName: "[project]/src/components/LoginPromptModal.tsx",
                            lineNumber: 15,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>router.push("/login"),
                            className: "rounded-full px-5 py-2 text-sm font-semibold text-white",
                            style: {
                                backgroundColor: "#5D9252"
                            },
                            children: "Go to login"
                        }, void 0, false, {
                            fileName: "[project]/src/components/LoginPromptModal.tsx",
                            lineNumber: 21,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/LoginPromptModal.tsx",
                    lineNumber: 14,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/LoginPromptModal.tsx",
            lineNumber: 11,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/LoginPromptModal.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
_s(LoginPromptModal, "fN7XvhJ+p5oE6+Xlo0NJmXpxjC8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = LoginPromptModal;
var _c;
__turbopack_context__.k.register(_c, "LoginPromptModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/RouteGuard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RouteGuard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LoginPromptModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/LoginPromptModal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
// Public routes that do not require authentication
const PUBLIC_PATHS = new Set([
    "/homepage",
    "/login",
    "/register",
    "/register/student",
    "/register/company",
    "/register/professor",
    "/oauth/callback"
]);
function isPublicPath(pathname) {
    if (PUBLIC_PATHS.has(pathname)) return true;
    // Allow nested register routes
    if (pathname.startsWith("/register/")) return true;
    return false;
}
function RouteGuard(param) {
    let { children } = param;
    _s();
    const { user, isReady } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RouteGuard.useEffect": ()=>{
            // no redirect; show modal for unauthenticated protected routes
            if (!isReady) return;
        }
    }["RouteGuard.useEffect"], [
        isReady
    ]);
    // While auth is hydrating, or redirecting an unauth user, don't render protected content
    if (!isReady) return null;
    const isPublic = isPublicPath(pathname);
    if (!user && !isPublic) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$LoginPromptModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            isOpen: true
        }, void 0, false, {
            fileName: "[project]/src/components/RouteGuard.tsx",
            lineNumber: 40,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false);
}
_s(RouteGuard, "rSPvBt6HxbNYhhqK6wXUVBJXZrg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = RouteGuard;
var _c;
__turbopack_context__.k.register(_c, "RouteGuard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/CompanyOnboardingModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CompanyOnboardingModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$companyprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/companyprofile.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function CompanyOnboardingModal(param) {
    let { isOpen, onClose } = param;
    _s();
    const overlayRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const nameRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [companyName, setCompanyName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [country, setCountry] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [description, setDescription] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Basic country list for dropdown; adjust as needed
    const COUNTRIES = [
        "Afghanistan",
        "Albania",
        "Algeria",
        "Andorra",
        "Angola",
        "Argentina",
        "Armenia",
        "Australia",
        "Austria",
        "Azerbaijan",
        "Bahamas",
        "Bahrain",
        "Bangladesh",
        "Barbados",
        "Belarus",
        "Belgium",
        "Belize",
        "Benin",
        "Bhutan",
        "Bolivia",
        "Bosnia and Herzegovina",
        "Botswana",
        "Brazil",
        "Brunei",
        "Bulgaria",
        "Burkina Faso",
        "Burundi",
        "Cambodia",
        "Cameroon",
        "Canada",
        "Cape Verde",
        "Central African Republic",
        "Chad",
        "Chile",
        "China",
        "Colombia",
        "Comoros",
        "Congo (Congo-Brazzaville)",
        "Costa Rica",
        "Croatia",
        "Cuba",
        "Cyprus",
        "Czechia",
        "Democratic Republic of the Congo",
        "Denmark",
        "Djibouti",
        "Dominica",
        "Dominican Republic",
        "Ecuador",
        "Egypt",
        "El Salvador",
        "Equatorial Guinea",
        "Eritrea",
        "Estonia",
        "Eswatini",
        "Ethiopia",
        "Fiji",
        "Finland",
        "France",
        "Gabon",
        "Gambia",
        "Georgia",
        "Germany",
        "Ghana",
        "Greece",
        "Grenada",
        "Guatemala",
        "Guinea",
        "Guinea-Bissau",
        "Guyana",
        "Haiti",
        "Honduras",
        "Hungary",
        "Iceland",
        "India",
        "Indonesia",
        "Iran",
        "Iraq",
        "Ireland",
        "Israel",
        "Italy",
        "Jamaica",
        "Japan",
        "Jordan",
        "Kazakhstan",
        "Kenya",
        "Kiribati",
        "Kuwait",
        "Kyrgyzstan",
        "Laos",
        "Latvia",
        "Lebanon",
        "Lesotho",
        "Liberia",
        "Libya",
        "Liechtenstein",
        "Lithuania",
        "Luxembourg",
        "Madagascar",
        "Malawi",
        "Malaysia",
        "Maldives",
        "Mali",
        "Malta",
        "Marshall Islands",
        "Mauritania",
        "Mauritius",
        "Mexico",
        "Micronesia",
        "Moldova",
        "Monaco",
        "Mongolia",
        "Montenegro",
        "Morocco",
        "Mozambique",
        "Myanmar",
        "Namibia",
        "Nauru",
        "Nepal",
        "Netherlands",
        "New Zealand",
        "Nicaragua",
        "Niger",
        "Nigeria",
        "North Korea",
        "North Macedonia",
        "Norway",
        "Oman",
        "Pakistan",
        "Palau",
        "Panama",
        "Papua New Guinea",
        "Paraguay",
        "Peru",
        "Philippines",
        "Poland",
        "Portugal",
        "Qatar",
        "Romania",
        "Russia",
        "Rwanda",
        "Saint Kitts and Nevis",
        "Saint Lucia",
        "Saint Vincent and the Grenadines",
        "Samoa",
        "San Marino",
        "Sao Tome and Principe",
        "Saudi Arabia",
        "Senegal",
        "Serbia",
        "Seychelles",
        "Sierra Leone",
        "Singapore",
        "Slovakia",
        "Slovenia",
        "Solomon Islands",
        "Somalia",
        "South Africa",
        "South Korea",
        "South Sudan",
        "Spain",
        "Sri Lanka",
        "Sudan",
        "Suriname",
        "Sweden",
        "Switzerland",
        "Syria",
        "Taiwan",
        "Tajikistan",
        "Tanzania",
        "Thailand",
        "Timor-Leste",
        "Togo",
        "Tonga",
        "Trinidad and Tobago",
        "Tunisia",
        "Turkey",
        "Turkmenistan",
        "Tuvalu",
        "Uganda",
        "Ukraine",
        "United Arab Emirates",
        "United Kingdom",
        "United States",
        "Uruguay",
        "Uzbekistan",
        "Vanuatu",
        "Vatican City",
        "Venezuela",
        "Vietnam",
        "Yemen",
        "Zambia",
        "Zimbabwe"
    ];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CompanyOnboardingModal.useEffect": ()=>{
            if (isOpen) {
                setError(null);
                setSaving(false);
                setTimeout({
                    "CompanyOnboardingModal.useEffect": ()=>{
                        var _nameRef_current;
                        return (_nameRef_current = nameRef.current) === null || _nameRef_current === void 0 ? void 0 : _nameRef_current.focus();
                    }
                }["CompanyOnboardingModal.useEffect"], 0);
            }
        }
    }["CompanyOnboardingModal.useEffect"], [
        isOpen
    ]);
    if (!isOpen) return null;
    const canSave = [
        companyName,
        country,
        description
    ].every((v)=>(v !== null && v !== void 0 ? v : "").trim().length > 0);
    const handleSave = async ()=>{
        if (!canSave || saving) return;
        setSaving(true);
        setError(null);
        try {
            // Save with explicit country field
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$companyprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateCompanyProfile"])({
                company_name: companyName,
                description,
                industry: "",
                tel: "",
                location: "",
                country
            });
            onClose();
        } catch (e) {
            setError((e === null || e === void 0 ? void 0 : e.message) || "Failed to save company info");
        } finally{
            setSaving(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: overlayRef,
        className: "fixed inset-0 z-[110] flex items-center justify-center bg-black/40 p-4",
        role: "dialog",
        "aria-modal": "true",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-lg rounded-2xl bg-white shadow-xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between px-5 py-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-lg font-semibold",
                        children: "Company Information"
                    }, void 0, false, {
                        fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                        lineNumber: 261,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                    lineNumber: 260,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-4 px-5 pb-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-medium",
                                    children: "Company Name"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                                    lineNumber: 267,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    ref: nameRef,
                                    type: "text",
                                    className: "rounded-md border px-3 py-2 text-sm",
                                    value: companyName,
                                    onChange: (e)=>setCompanyName(e.target.value)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                                    lineNumber: 268,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                            lineNumber: 266,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-medium",
                                    children: "Country"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                                    lineNumber: 278,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    className: "rounded-md border px-3 py-2 text-sm bg-white",
                                    value: country,
                                    onChange: (e)=>setCountry(e.target.value),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            disabled: true,
                                            children: "Select a country"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                                            lineNumber: 284,
                                            columnNumber: 15
                                        }, this),
                                        COUNTRIES.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: c,
                                                children: c
                                            }, c, false, {
                                                fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                                                lineNumber: 288,
                                                columnNumber: 17
                                            }, this))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                                    lineNumber: 279,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                            lineNumber: 277,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "text-sm font-medium",
                                    children: "Description"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                                    lineNumber: 296,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                    className: "h-28 rounded-md border px-3 py-2 text-sm",
                                    value: description,
                                    onChange: (e)=>setDescription(e.target.value)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                                    lineNumber: 297,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                            lineNumber: 295,
                            columnNumber: 11
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "rounded-md bg-red-50 px-3 py-2 text-sm text-red-600",
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                            lineNumber: 305,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                    lineNumber: 265,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-end gap-2 rounded-b-2xl bg-gray-50 px-5 py-3",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleSave,
                        disabled: !canSave || saving,
                        className: "rounded-full bg-midgreen-500 px-5 py-2 text-sm font-semibold text-white disabled:opacity-50",
                        children: saving ? "Saving…" : "Save"
                    }, void 0, false, {
                        fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                        lineNumber: 310,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
                    lineNumber: 309,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
            lineNumber: 259,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/CompanyOnboardingModal.tsx",
        lineNumber: 253,
        columnNumber: 5
    }, this);
}
_s(CompanyOnboardingModal, "J//17cZW/WNjT5vwqQ8Poy7axF0=");
_c = CompanyOnboardingModal;
var _c;
__turbopack_context__.k.register(_c, "CompanyOnboardingModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/api/user.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/api/user.ts
__turbopack_context__.s([
    "getAuthMe",
    ()=>getAuthMe,
    "updateUserRole",
    ()=>updateUserRole
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/base.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/httpError.ts [app-client] (ecmascript)");
;
;
function maskToken(t) {
    if (!t) return "(none)";
    if (t.length <= 8) return t;
    return "".concat(t.slice(0, 4), "...").concat(t.slice(-4));
}
async function getAuthMe(token) {
    const headers = {
        "Content-Type": "application/json"
    };
    if (token) headers["Authorization"] = "Bearer ".concat(token);
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/auth/me"), {
        method: "GET",
        headers,
        credentials: "include"
    });
    if (!res.ok) {
        throw new Error(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$httpError$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(res));
    }
    const raw = await res.text();
    let json = {};
    try {
        json = JSON.parse(raw);
    } catch (e) {}
    return (json === null || json === void 0 ? void 0 : json.data) || json;
}
async function updateUserRole(role, tokenOverride) {
    const token = tokenOverride || localStorage.getItem("access_token") || "";
    const headers = {
        "Content-Type": "application/json"
    };
    if (token) headers["Authorization"] = "Bearer ".concat(token);
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/user/role"), {
        method: "PATCH",
        headers,
        body: JSON.stringify({
            role
        }),
        credentials: "include"
    });
    const raw = await res.text();
    console.log("updateUserRole response (role=".concat(role, "):"), maskToken(token), res.status, raw);
    if (!res.ok) {
        throw new Error(raw || "Failed to update role: ".concat(res.status, " ").concat(res.statusText));
    }
    let json = {};
    try {
        json = JSON.parse(raw);
    } catch (e) {}
    const data = (json === null || json === void 0 ? void 0 : json.data) || json;
    return data; // contains access_token, refresh_token, role, etc.
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/RoleBootstrap.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RoleBootstrap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$roleselector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/roleselector.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CompanyOnboardingModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/CompanyOnboardingModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/user.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$professorprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/professorprofile.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$companyprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/companyprofile.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function normalizeRole(r) {
    const raw = (r !== null && r !== void 0 ? r : "").trim().toLowerCase();
    if (!raw || raw.includes("unknown") || raw.includes("unset")) return "Unknown";
    if (raw.includes("company")) return "Company";
    if (raw.includes("student")) return "Student";
    if (raw.includes("professor")) return "Professor";
    return raw.charAt(0).toUpperCase() + raw.slice(1);
}
function RoleBootstrap() {
    _s();
    const { user, isReady, login } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const [showRoleModal, setShowRoleModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [patchingRole, setPatchingRole] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showCompanyOnboarding, setShowCompanyOnboarding] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const isUnknown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "RoleBootstrap.useMemo[isUnknown]": ()=>normalizeRole(user === null || user === void 0 ? void 0 : user.role) === "Unknown"
    }["RoleBootstrap.useMemo[isUnknown]"], [
        user === null || user === void 0 ? void 0 : user.role
    ]);
    // Persist helper for new tokens coming from the backend
    function persistTokens(tokenPair) {
        if (tokenPair === null || tokenPair === void 0 ? void 0 : tokenPair.access_token) localStorage.setItem("access_token", tokenPair.access_token);
        if (tokenPair === null || tokenPair === void 0 ? void 0 : tokenPair.refresh_token) localStorage.setItem("refresh_token", tokenPair.refresh_token);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RoleBootstrap.useEffect": ()=>{
            if (!isReady) return;
            if (user && isUnknown) {
                setShowRoleModal(true);
            } else {
                setShowRoleModal(false);
            }
            // If user is a Company and signup flow marked onboarding, open only if country is empty
            ({
                "RoleBootstrap.useEffect": async ()=>{
                    try {
                        var _user_role;
                        const roleNorm = ((_user_role = user === null || user === void 0 ? void 0 : user.role) !== null && _user_role !== void 0 ? _user_role : "").toLowerCase();
                        if (!roleNorm.includes("company")) return;
                        const needs = ("TURBOPACK compile-time truthy", 1) ? localStorage.getItem("needs_company_onboarding") : "TURBOPACK unreachable";
                        if (needs !== "1") return;
                        // Check profile country before showing modal
                        try {
                            const profile = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$companyprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCompanyProfile"])();
                            const shouldOpen = !profile || profile.country === "";
                            if (shouldOpen) {
                                setShowCompanyOnboarding(true);
                            } else {
                                // Country already set; clear the flag so it won't show in future logins
                                if ("TURBOPACK compile-time truthy", 1) localStorage.removeItem("needs_company_onboarding");
                            }
                        } catch (e) {
                            console.warn("company profile check failed", e);
                            // Open modal on failure to avoid losing the opportunity in race conditions
                            setShowCompanyOnboarding(true);
                        }
                    } catch (e) {}
                }
            })["RoleBootstrap.useEffect"]();
        }
    }["RoleBootstrap.useEffect"], [
        isReady,
        user,
        isUnknown
    ]);
    // Note: no secondary guard; onboarding modal opens only when flagged by signup flow.
    async function handleRoleSelect(selected) {
        try {
            setPatchingRole(true);
            const payloadRole = selected.toLowerCase() === "student" ? "Student" : selected.toLowerCase() === "company" ? "Company" : selected.toLowerCase() === "professor" ? "Professor" : "Student";
            const patchData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateUserRole"])(payloadRole);
            persistTokens({
                access_token: patchData.access_token,
                refresh_token: patchData.refresh_token
            });
            const newToken = patchData.access_token || localStorage.getItem("access_token") || "";
            const me2 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$user$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuthMe"])(newToken);
            var _me2_role, _ref;
            // Final role
            const finalRole = normalizeRole((_ref = (_me2_role = me2.role) !== null && _me2_role !== void 0 ? _me2_role : me2.roles) !== null && _ref !== void 0 ? _ref : patchData.role);
            var _localStorage_getItem, _localStorage_getItem1, _me2_user_name, _ref1, _me2_email, _ref2;
            // Update AuthContext (this updates Navbar too)
            login({
                access_token: (_localStorage_getItem = localStorage.getItem("access_token")) !== null && _localStorage_getItem !== void 0 ? _localStorage_getItem : "",
                refresh_token: (_localStorage_getItem1 = localStorage.getItem("refresh_token")) !== null && _localStorage_getItem1 !== void 0 ? _localStorage_getItem1 : "",
                user_name: (_ref1 = (_me2_user_name = me2.user_name) !== null && _me2_user_name !== void 0 ? _me2_user_name : patchData.user_name) !== null && _ref1 !== void 0 ? _ref1 : "",
                email: (_ref2 = (_me2_email = me2.email) !== null && _me2_email !== void 0 ? _me2_email : patchData.email) !== null && _ref2 !== void 0 ? _ref2 : "",
                roles: finalRole
            });
            if (finalRole === "Professor") {
                try {
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$professorprofile$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createProfessorProfile"])({
                        department: "computer",
                        faculty: "engineering"
                    });
                } catch (e) {
                    // Ignore if already exists or backend glitches
                    console.warn("Professor profile auto-create skipped:", e);
                }
            }
            if (finalRole !== "Unknown") {
                setShowRoleModal(false);
            }
            // If user chose Company, prompt for company info
            if (finalRole === "Company") {
                setShowCompanyOnboarding(true);
            }
        } catch (err) {
            console.error("Failed to update role:", err);
        // keep modal open for retry
        } finally{
            setPatchingRole(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            showRoleModal && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$roleselector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showRoleModal,
                onClose: ()=>!patchingRole && setShowRoleModal(false),
                onSelect: handleRoleSelect,
                disableClose: true
            }, void 0, false, {
                fileName: "[project]/src/components/RoleBootstrap.tsx",
                lineNumber: 130,
                columnNumber: 9
            }, this),
            showCompanyOnboarding && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CompanyOnboardingModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showCompanyOnboarding,
                onClose: ()=>{
                    try {
                        if ("TURBOPACK compile-time truthy", 1) localStorage.removeItem("needs_company_onboarding");
                    } catch (e) {}
                    setShowCompanyOnboarding(false);
                }
            }, void 0, false, {
                fileName: "[project]/src/components/RoleBootstrap.tsx",
                lineNumber: 138,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(RoleBootstrap, "Z0cVlGdzZT6C4QZyUyEiyzgm/6k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"]
    ];
});
_c = RoleBootstrap;
var _c;
__turbopack_context__.k.register(_c, "RoleBootstrap");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ClientLayout.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ClientLayout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Navbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Navbar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$ApplyCartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/ApplyCartContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RouteGuard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RouteGuard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RoleBootstrap$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/RoleBootstrap.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ClientLayout(param) {
    let { children } = param;
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const isOAuth = pathname === null || pathname === void 0 ? void 0 : pathname.startsWith("/oauth");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$ApplyCartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApplyCartProvider"], {
        children: [
            !isOAuth && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Navbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/ClientLayout.tsx",
                lineNumber: 16,
                columnNumber: 20
            }, this),
            isOAuth ? children : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RouteGuard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$RoleBootstrap$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/components/ClientLayout.tsx",
                        lineNumber: 19,
                        columnNumber: 11
                    }, this),
                    children
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ClientLayout.tsx",
                lineNumber: 18,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ClientLayout.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
_s(ClientLayout, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = ClientLayout;
var _c;
__turbopack_context__.k.register(_c, "ClientLayout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_c945e554._.js.map