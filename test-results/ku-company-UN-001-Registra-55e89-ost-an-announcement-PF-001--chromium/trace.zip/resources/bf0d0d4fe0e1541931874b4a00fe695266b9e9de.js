(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__fa3a7566._.css",
  "static/chunks/src_utils_httpError_ts_627587ad._.js",
  "static/chunks/src_c945e554._.js",
  "static/chunks/node_modules_0a990bfc._.js"
],
    source: "dynamic"
});
