(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/ApplyModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ApplyModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function ApplyModal(param) {
    let { isOpen, onClose, onSubmit, resumes, jobTitle, brandColor = "#5D9252" } = param;
    _s();
    const [mode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("existing");
    const [selectedResumeId, setSelectedResumeId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(undefined);
    // upload removed
    const overlayRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const initialFocusRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Reset when opened
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ApplyModal.useEffect": ()=>{
            if (isOpen) {
                var _resumes_;
                setSelectedResumeId((_resumes_ = resumes[0]) === null || _resumes_ === void 0 ? void 0 : _resumes_.id);
                // small delay to allow mount then focus
                setTimeout({
                    "ApplyModal.useEffect": ()=>{
                        var _initialFocusRef_current;
                        return (_initialFocusRef_current = initialFocusRef.current) === null || _initialFocusRef_current === void 0 ? void 0 : _initialFocusRef_current.focus();
                    }
                }["ApplyModal.useEffect"], 0);
            }
        }
    }["ApplyModal.useEffect"], [
        isOpen,
        resumes
    ]);
    // Close on ESC
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ApplyModal.useEffect": ()=>{
            if (!isOpen) return;
            const onKey = {
                "ApplyModal.useEffect.onKey": (e)=>{
                    if (e.key === "Escape") onClose();
                }
            }["ApplyModal.useEffect.onKey"];
            window.addEventListener("keydown", onKey);
            return ({
                "ApplyModal.useEffect": ()=>window.removeEventListener("keydown", onKey)
            })["ApplyModal.useEffect"];
        }
    }["ApplyModal.useEffect"], [
        isOpen,
        onClose
    ]);
    const canSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ApplyModal.useMemo[canSubmit]": ()=>!!selectedResumeId
    }["ApplyModal.useMemo[canSubmit]"], [
        selectedResumeId
    ]);
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: overlayRef,
        className: "fixed inset-0 z-[100] flex items-center justify-center bg-black/40 p-4",
        "aria-modal": "true",
        role: "dialog",
        "aria-labelledby": "apply-modal-title",
        onMouseDown: (e)=>{
            // close when clicking backdrop (but not when dragging inside)
            if (e.target === overlayRef.current) onClose();
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-lg rounded-2xl bg-white shadow-xl outline outline-1 outline-gray-200",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between rounded-t-2xl px-5 py-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            id: "apply-modal-title",
                            className: "text-lg font-semibold",
                            children: [
                                "Apply to ",
                                jobTitle !== null && jobTitle !== void 0 ? jobTitle : "this job"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/ApplyModal.tsx",
                            lineNumber: 74,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "inline-flex h-8 w-8 items-center justify-center rounded-full text-gray-500 hover:bg-gray-100",
                            "aria-label": "Close",
                            title: "Close",
                            children: "✕"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ApplyModal.tsx",
                            lineNumber: 77,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ApplyModal.tsx",
                    lineNumber: 73,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-5",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-sm font-medium text-gray-700",
                            children: "Choose your resume"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ApplyModal.tsx",
                            lineNumber: 90,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/ApplyModal.tsx",
                        lineNumber: 89,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/ApplyModal.tsx",
                    lineNumber: 88,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-5 pb-5",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        className: "space-y-3",
                        children: [
                            resumes.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: "rounded-lg border border-dashed p-4 text-sm text-gray-600",
                                children: "No uploaded resume yet. Please upload one from your profile."
                            }, void 0, false, {
                                fileName: "[project]/src/components/ApplyModal.tsx",
                                lineNumber: 99,
                                columnNumber: 17
                            }, this),
                            resumes.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    className: "flex items-center justify-between rounded-lg border px-4 py-3 ".concat(selectedResumeId === r.id ? "ring-2 ring-offset-0" : ""),
                                    style: {
                                        borderColor: "#e5e7eb",
                                        boxShadow: selectedResumeId === r.id ? "0 0 0 2px ".concat(brandColor) : undefined
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "flex flex-1 cursor-pointer items-center gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "radio",
                                                    name: "resume",
                                                    value: r.id,
                                                    checked: selectedResumeId === r.id,
                                                    onChange: ()=>setSelectedResumeId(r.id),
                                                    className: "h-4 w-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ApplyModal.tsx",
                                                    lineNumber: 115,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "font-medium",
                                                            children: r.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ApplyModal.tsx",
                                                            lineNumber: 124,
                                                            columnNumber: 23
                                                        }, this),
                                                        (r.updatedAt || r.size) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs text-gray-500",
                                                            children: [
                                                                r.updatedAt ? r.updatedAt : "",
                                                                " ",
                                                                r.updatedAt && r.size ? "•" : "",
                                                                " ",
                                                                r.size ? r.size : ""
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ApplyModal.tsx",
                                                            lineNumber: 126,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/components/ApplyModal.tsx",
                                                    lineNumber: 123,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/ApplyModal.tsx",
                                            lineNumber: 114,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: "#",
                                            className: "text-xs font-medium text-gray-600 hover:underline",
                                            children: "Preview"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ApplyModal.tsx",
                                            lineNumber: 133,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, r.id, true, {
                                    fileName: "[project]/src/components/ApplyModal.tsx",
                                    lineNumber: 104,
                                    columnNumber: 17
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ApplyModal.tsx",
                        lineNumber: 97,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/ApplyModal.tsx",
                    lineNumber: 95,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-end gap-2 rounded-b-2xl bg-gray-50 px-5 py-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "rounded-full border px-4 py-2 text-sm hover:bg-gray-100",
                            children: "Cancel"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ApplyModal.tsx",
                            lineNumber: 144,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            disabled: !canSubmit,
                            onClick: ()=>onSubmit({
                                    mode,
                                    resumeId: selectedResumeId
                                }),
                            className: "rounded-full px-5 py-2 text-sm font-semibold text-white disabled:opacity-50",
                            style: {
                                backgroundColor: brandColor
                            },
                            children: "Submit application"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ApplyModal.tsx",
                            lineNumber: 150,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ApplyModal.tsx",
                    lineNumber: 143,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/ApplyModal.tsx",
            lineNumber: 71,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ApplyModal.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
_s(ApplyModal, "OVxRnvEXMrPPhdrc5+S46hM0clY=");
_c = ApplyModal;
var _c;
__turbopack_context__.k.register(_c, "ApplyModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Markdown.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Markdown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
;
function renderInline(text) {
    const nodes = [];
    let rest = text;
    // Simple link pattern: [label](url)
    const linkRe = /\[([^\]]+)\]\(([^\s)]+)\)/g;
    // Process backticks first to avoid formatting inside code
    const codeSplit = rest.split(/`/);
    for(let i = 0; i < codeSplit.length; i++){
        const segment = codeSplit[i];
        if (i % 2 === 1) {
            nodes.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                children: segment
            }, "code-".concat(i), false, {
                fileName: "[project]/src/components/Markdown.tsx",
                lineNumber: 22,
                columnNumber: 18
            }, this));
        } else {
            // Within non-code segment apply bold, italic, links
            let parts = [];
            let lastIndex = 0;
            let m;
            while(m = linkRe.exec(segment)){
                if (m.index > lastIndex) parts.push(segment.slice(lastIndex, m.index));
                parts.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    href: m[2],
                    className: "underline text-blue-600 hover:text-blue-800",
                    children: m[1]
                }, "lnk-".concat(i, "-").concat(m.index), false, {
                    fileName: "[project]/src/components/Markdown.tsx",
                    lineNumber: 31,
                    columnNumber: 11
                }, this));
                lastIndex = m.index + m[0].length;
            }
            if (lastIndex < segment.length) parts.push(segment.slice(lastIndex));
            // Now apply bold and italics inside remaining strings
            const fmtParts = [];
            parts.forEach((p, idx)=>{
                if (typeof p !== "string") {
                    fmtParts.push(p);
                    return;
                }
                // bold: **text**
                const boldSplit = p.split(/\*\*(.+?)\*\*/g);
                for(let b = 0; b < boldSplit.length; b++){
                    const bseg = boldSplit[b];
                    if (b % 2 === 1) {
                        fmtParts.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                            children: bseg
                        }, "b-".concat(i, "-").concat(idx, "-").concat(b), false, {
                            fileName: "[project]/src/components/Markdown.tsx",
                            lineNumber: 48,
                            columnNumber: 27
                        }, this));
                    } else {
                        // italics: *text*
                        const italSplit = bseg.split(/\*(.+?)\*/g);
                        for(let s = 0; s < italSplit.length; s++){
                            const iseg = italSplit[s];
                            if (s % 2 === 1) fmtParts.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("em", {
                                children: iseg
                            }, "i-".concat(i, "-").concat(idx, "-").concat(b, "-").concat(s), false, {
                                fileName: "[project]/src/components/Markdown.tsx",
                                lineNumber: 54,
                                columnNumber: 46
                            }, this));
                            else fmtParts.push(iseg);
                        }
                    }
                }
            });
            nodes.push(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                children: fmtParts
            }, "t-".concat(i), false, {
                fileName: "[project]/src/components/Markdown.tsx",
                lineNumber: 61,
                columnNumber: 18
            }, this));
        }
    }
    return nodes;
}
function Markdown(param) {
    let { content, className } = param;
    const text = (content !== null && content !== void 0 ? content : "").replace(/\r\n/g, "\n");
    const lines = text.split("\n");
    const blocks = [];
    let para = [];
    let list = null;
    let code = null;
    const flushPara = ()=>{
        if (para.length) {
            blocks.push({
                type: "p",
                text: para
            });
            para = [];
        }
    };
    const flushList = ()=>{
        if (list && list.length) {
            blocks.push({
                type: "ul",
                items: list
            });
        }
        list = null;
    };
    const flushCode = ()=>{
        if (code) {
            blocks.push({
                type: "code",
                lang: code.lang,
                lines: code.lines
            });
        }
        code = null;
    };
    for (const raw of lines){
        const line = raw.replace(/\t/g, "  ");
        if (code) {
            if (/^```/.test(line)) {
                flushCode();
                continue;
            }
            code.lines.push(raw);
            continue;
        }
        if (/^```/.test(line)) {
            flushPara();
            flushList();
            const lang = line.replace(/^```+\s*/, "").trim() || null;
            code = {
                lang,
                lines: []
            };
            continue;
        }
        if (!line.trim()) {
            flushPara();
            flushList();
            continue;
        }
        const heading = line.match(/^(#{1,6})\s+(.+)$/);
        if (heading) {
            flushPara();
            flushList();
            const level = heading[1].length;
            blocks.push({
                type: "h".concat(level),
                text: heading[2]
            });
            continue;
        }
        const li = line.match(/^\s*[-*]\s+(.+)$/);
        if (li) {
            flushPara();
            (list || (list = [])).push(li[1]);
            continue;
        }
        // paragraph text
        if (list) flushList();
        para.push(line);
    }
    flushCode();
    flushList();
    flushPara();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (className ? className + " " : "") + "break-words",
        children: blocks.map((b, i)=>{
            switch(b.type){
                case "p":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "whitespace-pre-wrap break-words",
                        children: b.text.map((t, j)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                                children: [
                                    renderInline(t),
                                    j < b.text.length - 1 ? "\n" : null
                                ]
                            }, j, true, {
                                fileName: "[project]/src/components/Markdown.tsx",
                                lineNumber: 123,
                                columnNumber: 97
                            }, this))
                    }, i, false, {
                        fileName: "[project]/src/components/Markdown.tsx",
                        lineNumber: 123,
                        columnNumber: 20
                    }, this);
                case "ul":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        className: "list-disc pl-5 space-y-1",
                        children: b.items.map((it, j)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: "break-words",
                                children: renderInline(it)
                            }, j, false, {
                                fileName: "[project]/src/components/Markdown.tsx",
                                lineNumber: 127,
                                columnNumber: 41
                            }, this))
                    }, i, false, {
                        fileName: "[project]/src/components/Markdown.tsx",
                        lineNumber: 126,
                        columnNumber: 15
                    }, this);
                case "code":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                        className: "rounded-md bg-gray-100 p-3 overflow-x-auto",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                            children: b.lines.join("\n")
                        }, void 0, false, {
                            fileName: "[project]/src/components/Markdown.tsx",
                            lineNumber: 132,
                            columnNumber: 83
                        }, this)
                    }, i, false, {
                        fileName: "[project]/src/components/Markdown.tsx",
                        lineNumber: 132,
                        columnNumber: 15
                    }, this);
                case "h1":
                case "h2":
                case "h3":
                case "h4":
                case "h5":
                case "h6":
                    {
                        const L = b.type;
                        const Tag = L;
                        const size = L === "h1" ? " text-2xl" : L === "h2" ? " text-xl" : L === "h3" ? " text-lg" : "";
                        const spacing = L === "h1" ? " mt-4 mb-2" : L === "h2" ? " mt-3 mb-2" : " mt-2 mb-1";
                        const cls = "text-gray-900 font-semibold" + size + spacing + " break-words";
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Tag, {
                            className: cls,
                            children: renderInline(b.text)
                        }, i, false, {
                            fileName: "[project]/src/components/Markdown.tsx",
                            lineNumber: 145,
                            columnNumber: 20
                        }, this);
                    }
            }
        })
    }, void 0, false, {
        fileName: "[project]/src/components/Markdown.tsx",
        lineNumber: 119,
        columnNumber: 5
    }, this);
}
_c = Markdown;
var _c;
__turbopack_context__.k.register(_c, "Markdown");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/api/resume.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MAIN_RESUME_UPDATED_EVENT",
    ()=>MAIN_RESUME_UPDATED_EVENT,
    "deleteAllResumes",
    ()=>deleteAllResumes,
    "deleteResume",
    ()=>deleteResume,
    "getMainResume",
    ()=>getMainResume,
    "listResumes",
    ()=>listResumes,
    "setMainResume",
    ()=>setMainResume,
    "uploadResume",
    ()=>uploadResume
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/base.ts [app-client] (ecmascript)");
;
const MAIN_RESUME_UPDATED_EVENT = "main-resume-updated";
function unwrap(json) {
    var _json_data;
    return (_json_data = json === null || json === void 0 ? void 0 : json.data) !== null && _json_data !== void 0 ? _json_data : json;
}
function maskToken(t) {
    if (!t) return "(none)";
    return t.length > 8 ? "".concat(t.slice(0, 4), "...").concat(t.slice(-4)) : t;
}
function extractFileName(url) {
    try {
        var _url_split_pop;
        const raw = decodeURIComponent(((_url_split_pop = url.split("/").pop()) === null || _url_split_pop === void 0 ? void 0 : _url_split_pop.split("?")[0]) || "");
        const dashIndex = raw.indexOf("-");
        if (raw.startsWith("resume_") && dashIndex > 0) {
            return raw.substring(dashIndex + 1);
        }
        return raw;
    } catch (e) {
        return url;
    }
}
async function listResumes() {
    const token = localStorage.getItem("access_token") || "";
    const headers = {};
    if (token) headers["Authorization"] = "Bearer ".concat(token);
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/profile/resumes"), {
        method: "GET",
        headers,
        credentials: "include"
    });
    const raw = await res.text();
    console.log("🧾 [resumes] GET raw:", raw.slice(0, 500), "🔑", maskToken(token));
    if (!res.ok) {
        try {
            const j = JSON.parse(raw);
            if (j && (j.message === "Access Denied" || j.error === "Access Denied")) {
                console.warn("[resumes] Access Denied — returning empty list");
                return [];
            }
        } catch (e) {}
        throw new Error(raw || "Failed to fetch resumes");
    }
    let json = {};
    try {
        json = JSON.parse(raw);
    } catch (e) {}
    const list = Array.isArray(json === null || json === void 0 ? void 0 : json.resumes) ? json.resumes : [];
    return list.map((r)=>({
            id: r.id,
            employee_id: r.employee_id,
            file_url: r.file_url,
            name: extractFileName(r.file_url),
            is_main: !!r.is_main
        }));
}
async function getMainResume() {
    const token = localStorage.getItem("access_token") || "";
    const headers = {};
    if (token) headers["Authorization"] = "Bearer ".concat(token);
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/profile/resumes/main"), {
        method: "GET",
        headers,
        credentials: "include"
    });
    const raw = await res.text();
    console.log("🧾 [resumes] GET main raw:", raw.slice(0, 400));
    if (res.status === 404) return null;
    if (!res.ok) {
        // Fallback: some servers reject empty Authorization header; try listing and finding is_main
        try {
            const list = await listResumes();
            const m = list.find((r)=>r.is_main);
            return m || null;
        } catch (e) {}
        throw new Error(raw || "Failed to fetch main resume");
    }
    let json = {};
    try {
        json = JSON.parse(raw);
    } catch (e) {}
    const item = unwrap(json);
    if (!item) return null;
    return {
        id: item.id,
        employee_id: item.employee_id,
        file_url: item.file_url,
        name: extractFileName(item.file_url),
        is_main: true
    };
}
async function setMainResume(id) {
    const token = localStorage.getItem("access_token") || "";
    const headers = {};
    if (token) headers["Authorization"] = "Bearer ".concat(token);
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/profile/resumes/").concat(id, "/set-main"), {
        method: "PATCH",
        headers,
        credentials: "include"
    });
    const raw = await res.text();
    console.log("⭐ [resumes] PATCH set-main ".concat(id, " raw:"), raw);
    if (!res.ok) throw new Error(raw || "Failed to set main resume");
}
async function uploadResume(file) {
    const token = localStorage.getItem("access_token") || "";
    if (file.type !== "application/pdf") throw new Error("Only PDF files are allowed.");
    if (file.size > 10 * 1024 * 1024) throw new Error("File must be ≤ 10MB.");
    const form = new FormData();
    form.append("resume", file);
    const headers = {};
    if (token) headers["Authorization"] = "Bearer ".concat(token);
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/profile/resumes"), {
        method: "POST",
        headers,
        body: form,
        credentials: "include"
    });
    const raw = await res.text();
    console.log("🧾 [resumes] POST raw:", raw.slice(0, 500));
    if (!res.ok) throw new Error(raw || "Failed to upload resume");
    let json = {};
    try {
        json = JSON.parse(raw);
    } catch (e) {}
    return unwrap(json);
}
async function deleteAllResumes() {
    const token = localStorage.getItem("access_token") || "";
    const headers = {};
    if (token) headers["Authorization"] = "Bearer ".concat(token);
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/profile/resumes"), {
        method: "DELETE",
        headers,
        credentials: "include"
    });
    const raw = await res.text();
    console.log("🧾 [resumes] DELETE ALL raw:", raw);
    if (!res.ok) throw new Error(raw || "Failed to delete resumes");
}
async function deleteResume(id) {
    const token = localStorage.getItem("access_token") || "";
    const headers = {};
    if (token) headers["Authorization"] = "Bearer ".concat(token);
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/profile/resumes/").concat(id), {
        method: "DELETE",
        headers,
        credentials: "include"
    });
    const raw = await res.text();
    console.log("🗑️ [resumes] DELETE ".concat(id, " raw:"), raw);
    if (!res.ok) throw new Error(raw || "Failed to delete resume");
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/api/jobs.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "applyJobsBulk",
    ()=>applyJobsBulk,
    "applyToJob",
    ()=>applyToJob
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/base.ts [app-client] (ecmascript)");
;
async function applyToJob(jobPostId, resumeId) {
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/apply-job/").concat(jobPostId), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
        method: "POST",
        body: JSON.stringify({
            resume_id: resumeId
        }),
        credentials: "include"
    }));
    const text = await res.text();
    if (!res.ok) {
        throw new Error(text || "Failed to apply to job ".concat(jobPostId));
    }
    try {
        return JSON.parse(text);
    } catch (e) {
        return {
            ok: true
        };
    }
}
async function applyJobsBulk(resumeId, jobIds) {
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/checkout/apply-jobs"), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
        method: "POST",
        body: JSON.stringify({
            resume_id: resumeId,
            job_id: jobIds
        }),
        credentials: "include"
    }));
    const text = await res.text();
    if (!res.ok) {
        throw new Error(text || "Failed to apply to jobs");
    }
    try {
        return JSON.parse(text);
    } catch (e) {
        return {
            ok: true
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/api/applications.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "listMyApplications",
    ()=>listMyApplications
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/base.ts [app-client] (ecmascript)");
;
async function listMyApplications() {
    const res = await fetch("".concat(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE"], "/api/employee/my-applications"), (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
        method: "GET",
        credentials: "include"
    }));
    const text = await res.text();
    if (!res.ok) {
        try {
            const j = JSON.parse(text);
            if (j && (j.message === "Access Denied" || j.error === "Access Denied")) {
                return [];
            }
        } catch (e) {}
        throw new Error(text || "Failed to fetch applications");
    }
    try {
        const json = JSON.parse(text);
        var _json_data;
        const data = (_json_data = json === null || json === void 0 ? void 0 : json.data) !== null && _json_data !== void 0 ? _json_data : json;
        return Array.isArray(data) ? data : [];
    } catch (e) {
        return [];
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/find-job/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FindJobPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BuildingOfficeIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BuildingOfficeIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/BuildingOfficeIcon.js [app-client] (ecmascript) <export default as BuildingOfficeIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MapPinIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPinIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/MapPinIcon.js [app-client] (ecmascript) <export default as MapPinIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowTopRightOnSquareIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowTopRightOnSquareIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ArrowTopRightOnSquareIcon.js [app-client] (ecmascript) <export default as ArrowTopRightOnSquareIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ApplyModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ApplyModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Markdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Markdown.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$resume$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/resume.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$jobs$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/jobs.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/base.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$ApplyCartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/ApplyCartContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$applications$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/api/applications.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
const GREEN = "#5b8f5b";
const BASE_URL = ("TURBOPACK compile-time value", "http://localhost:8000") || "http://localhost:8000";
function FindJobPage() {
    _s();
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const { add, contains } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$ApplyCartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplyCart"])();
    const [jobs, setJobs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [keyword, setKeyword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [category, setCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("All");
    const [jobType, setJobType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("All");
    const [categories, setCategories] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        "All"
    ]);
    const [jobTypes, setJobTypes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        "All"
    ]);
    const [sortBy, setSortBy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("Newest");
    const [selectedId, setSelectedId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isApplyOpen, setIsApplyOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [resumes, setResumes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]); //  resume state
    const [appliedIds, setAppliedIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const canApply = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "FindJobPage.useMemo[canApply]": ()=>((user === null || user === void 0 ? void 0 : user.role) || "").toLowerCase() === "student"
    }["FindJobPage.useMemo[canApply]"], [
        user
    ]);
    // Re-sort when sort option changes without re-fetching
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FindJobPage.useEffect": ()=>{
            if (!jobs || jobs.length === 0) return;
            const sortKey = (sortBy || "Newest").toLowerCase();
            const sorted = [
                ...jobs
            ].sort({
                "FindJobPage.useEffect.sorted": (a, b)=>{
                    if (sortKey.includes("newest")) {
                        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
                    }
                    if (sortKey.includes("oldest")) {
                        return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
                    }
                    return 0;
                }
            }["FindJobPage.useEffect.sorted"]);
            setJobs(sorted);
        }
    }["FindJobPage.useEffect"], [
        sortBy
    ]);
    // Utility: fetch with token safely
    const authFetch = async (url)=>{
        const res = await fetch(url, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
            credentials: "include"
        }));
        return res;
    };
    const safeFetchJson = async (url)=>{
        try {
            const res = await authFetch(url);
            const text = await res.text();
            try {
                return JSON.parse(text);
            } catch (e) {
                console.warn("[".concat(url, "] Not JSON:"), text.slice(0, 100));
                return [];
            }
        } catch (err) {
            console.error("safeFetchJson error", err);
            return [];
        }
    };
    // Load dropdowns (category + jobType)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FindJobPage.useEffect": ()=>{
            async function fetchDropdowns() {
                try {
                    const [catData, typeData] = await Promise.all([
                        safeFetchJson("".concat(BASE_URL, "/api/job-postings/category")),
                        safeFetchJson("".concat(BASE_URL, "/api/job-postings/job-type"))
                    ]);
                    const extractArray = {
                        "FindJobPage.useEffect.fetchDropdowns.extractArray": (data)=>{
                            if (Array.isArray(data)) return data;
                            if (Array.isArray(data === null || data === void 0 ? void 0 : data.data)) return data.data;
                            if (Array.isArray(data === null || data === void 0 ? void 0 : data.categories)) return data.categories;
                            if (Array.isArray(data === null || data === void 0 ? void 0 : data.jobTypes)) return data.jobTypes;
                            if (Array.isArray(data === null || data === void 0 ? void 0 : data.job_types)) return data.job_types;
                            if (Array.isArray(Object.values(data)[0])) return Object.values(data)[0];
                            return [];
                        }
                    }["FindJobPage.useEffect.fetchDropdowns.extractArray"];
                    const catArray = extractArray(catData);
                    const typeArray = extractArray(typeData);
                    setCategories([
                        "All",
                        ...catArray
                    ]);
                    setJobTypes([
                        "All",
                        ...typeArray
                    ]);
                } catch (err) {
                    console.error("Failed to load dropdowns", err);
                }
            }
            fetchDropdowns();
        }
    }["FindJobPage.useEffect"], []);
    // -------------------------------
    // Fetch job postings
    // -------------------------------
    const fetchJobs = async ()=>{
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (keyword) params.append("keyword", keyword);
            if (category !== "All") params.append("category", category);
            if (jobType !== "All") params.append("jobType", jobType);
            const url = "".concat(BASE_URL, "/api/job-postings/?").concat(params.toString());
            console.log("Fetching:", url);
            const res = await fetch(url, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$base$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["buildInit"])({
                credentials: "include"
            }));
            if (!res.ok) {
                const text = await res.text();
                console.error("Server error detail:", text);
                throw new Error("HTTP ".concat(res.status, ": ").concat(text));
            }
            const data = await res.json();
            let jobList = data.job_postings || data.data || data;
            const now = Date.now();
            let filtered = (jobList || []).filter((j)=>{
                if (!(j === null || j === void 0 ? void 0 : j.expired_at)) return true;
                const exp = new Date(j.expired_at).getTime();
                return isFinite(exp) ? exp >= now : true;
            });
            // Client-side sorting (backend defaults to updated_at desc)
            const sortKey = (sortBy || "Newest").toLowerCase();
            filtered = [
                ...filtered
            ].sort((a, b)=>{
                if (sortKey.includes("newest")) {
                    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
                }
                if (sortKey.includes("oldest")) {
                    return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
                }
                return 0;
            });
            setJobs(filtered);
            if (filtered.length > 0) setSelectedId(filtered[0].id);
        } catch (err) {
            console.error("Failed to fetch jobs", err);
            setJobs([]);
        } finally{
            setLoading(false);
        }
    };
    // -------------------------------
    // Fetch resumes from backend
    // -------------------------------
    const fetchResumes = async ()=>{
        try {
            const resumeList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$resume$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["listResumes"])();
            const mapped = (resumeList || []).map((r)=>({
                    id: String(r.id),
                    name: r.name || "Unnamed Resume"
                }));
            setResumes(mapped);
        } catch (err) {
            console.error("Failed to fetch resumes", err);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FindJobPage.useEffect": ()=>{
            fetchJobs();
        }
    }["FindJobPage.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "FindJobPage.useEffect": ()=>{
            if (canApply) {
                fetchResumes();
                ({
                    "FindJobPage.useEffect": async ()=>{
                        try {
                            const apps = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$applications$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["listMyApplications"])();
                            const ids = new Set();
                            (apps || []).forEach({
                                "FindJobPage.useEffect": (a)=>{
                                    var _a_job_post;
                                    if (typeof (a === null || a === void 0 ? void 0 : a.job_id) === "number") ids.add(a.job_id);
                                    else if (typeof (a === null || a === void 0 ? void 0 : (_a_job_post = a.job_post) === null || _a_job_post === void 0 ? void 0 : _a_job_post.id) === "number") ids.add(a.job_post.id);
                                }
                            }["FindJobPage.useEffect"]);
                            setAppliedIds(ids);
                        } catch (e) {
                        // ignore access issues
                        }
                    }
                })["FindJobPage.useEffect"]();
            } else {
                setResumes([]);
                setAppliedIds(new Set());
            }
        }
    }["FindJobPage.useEffect"], [
        canApply
    ]);
    var _jobs_find;
    // -------------------------------
    // Selected job
    // -------------------------------
    const selected = (_jobs_find = jobs.find((j)=>j.id === selectedId)) !== null && _jobs_find !== void 0 ? _jobs_find : null;
    // -------------------------------
    // Apply handler
    // -------------------------------
    const handleApply = async (payload)=>{
        try {
            if (!(selected === null || selected === void 0 ? void 0 : selected.id)) {
                alert("Please select a job first.");
                return;
            }
            let resumeIdToUse = null;
            if (payload.mode === "existing") {
                if (!payload.resumeId) {
                    alert("Please select a resume.");
                    return;
                }
                resumeIdToUse = parseInt(payload.resumeId, 10);
            } else if (payload.mode === "upload") {
                var _this;
                if (!payload.file) {
                    alert("Please choose a file to upload.");
                    return;
                }
                const uploaded = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$resume$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadResume"])(payload.file);
                resumeIdToUse = (_this = uploaded) === null || _this === void 0 ? void 0 : _this.id;
            }
            if (!resumeIdToUse) {
                alert("Unable to determine resume to use.");
                return;
            }
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$jobs$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyToJob"])(selected.id, resumeIdToUse);
            setAppliedIds((prev)=>new Set([
                    ...Array.from(prev),
                    selected.id
                ]));
            setIsApplyOpen(false);
            alert("Application submitted successfully.");
        } catch (err) {
            console.error("Apply failed", err);
            alert(typeof (err === null || err === void 0 ? void 0 : err.message) === "string" ? err.message : "Failed to submit application.");
        }
    };
    var _selected_location;
    // -------------------------------
    // Render
    // -------------------------------
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "rounded-2xl border bg-white p-3 sm:p-4 shadow-sm",
                style: {
                    borderColor: GREEN
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-wrap items-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            value: keyword,
                            onChange: (e)=>setKeyword(e.target.value),
                            placeholder: "Keyword",
                            className: "h-10 w-[200px] flex-1 rounded-full border px-4 text-sm focus:outline-none focus:ring"
                        }, void 0, false, {
                            fileName: "[project]/src/app/find-job/page.tsx",
                            lineNumber: 286,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                            value: category,
                            "aria-label": "Position",
                            onChange: (e)=>setCategory(e.target.value),
                            className: "h-10 w-[180px] rounded-full border px-3 text-sm",
                            children: categories.map((c, i)=>{
                                const label = typeof c === "object" ? c.label || c.name || c.title || c.value || "Unnamed" : String(c);
                                const value = typeof c === "object" ? c.value || c.name || c.title || label : String(c);
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: value,
                                    children: label
                                }, "".concat(i, "-").concat(value), false, {
                                    fileName: "[project]/src/app/find-job/page.tsx",
                                    lineNumber: 308,
                                    columnNumber: 17
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/app/find-job/page.tsx",
                            lineNumber: 293,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                            value: jobType,
                            "aria-label": "Job type",
                            onChange: (e)=>setJobType(e.target.value),
                            className: "h-10 w-[180px] rounded-full border px-3 text-sm",
                            children: jobTypes.map((t, i)=>{
                                const label = typeof t === "object" ? t.label || t.name || t.title || t.value || "Unnamed" : String(t);
                                const value = typeof t === "object" ? t.value || t.name || t.title || label : String(t);
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: value,
                                    children: label
                                }, "".concat(i, "-").concat(value), false, {
                                    fileName: "[project]/src/app/find-job/page.tsx",
                                    lineNumber: 330,
                                    columnNumber: 17
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/src/app/find-job/page.tsx",
                            lineNumber: 315,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "ml-auto flex gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: sortBy,
                                    onChange: (e)=>setSortBy(e.target.value),
                                    className: "h-10 rounded-full border px-3 text-sm",
                                    "aria-label": "Sort",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: "Newest"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/find-job/page.tsx",
                                            lineNumber: 344,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: "Oldest"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/find-job/page.tsx",
                                            lineNumber: 345,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/find-job/page.tsx",
                                    lineNumber: 338,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "rounded-full px-4 py-2 text-sm text-white",
                                    style: {
                                        backgroundColor: GREEN
                                    },
                                    onClick: fetchJobs,
                                    children: "Search"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/find-job/page.tsx",
                                    lineNumber: 347,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "rounded-full border px-4 py-2 text-sm hover:bg-gray-50",
                                    onClick: ()=>{
                                        setKeyword("");
                                        setCategory("All");
                                        setJobType("All");
                                        fetchJobs();
                                    },
                                    children: "Reset"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/find-job/page.tsx",
                                    lineNumber: 354,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/find-job/page.tsx",
                            lineNumber: 337,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/find-job/page.tsx",
                    lineNumber: 285,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/find-job/page.tsx",
                lineNumber: 281,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-6 grid gap-6 lg:grid-cols-[420px,1fr]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                        className: "space-y-3",
                        children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-gray-600 text-sm",
                            children: "Loading jobs..."
                        }, void 0, false, {
                            fileName: "[project]/src/app/find-job/page.tsx",
                            lineNumber: 373,
                            columnNumber: 13
                        }, this) : jobs.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "rounded-2xl border p-6 text-sm text-gray-600",
                            children: "No jobs match your filters."
                        }, void 0, false, {
                            fileName: "[project]/src/app/find-job/page.tsx",
                            lineNumber: 375,
                            columnNumber: 13
                        }, this) : jobs.map((job)=>{
                            const active = job.id === selectedId;
                            var _job_location;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setSelectedId(job.id),
                                className: "relative w-full rounded-2xl border bg-white p-4 text-left shadow-sm transition ".concat(active ? "ring-2" : ""),
                                style: {
                                    borderColor: GREEN,
                                    boxShadow: active ? "0 0 0 2px ".concat(GREEN) : undefined
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute right-6 top-2 h-14 w-14 overflow-hidden rounded-full border bg-white shadow-sm",
                                        children: job.company_profile_image ? // Company profile image from backend
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: job.company_profile_image,
                                            alt: (job.company_name || 'Company') + ' logo',
                                            className: "h-full w-full object-cover"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/find-job/page.tsx",
                                            lineNumber: 396,
                                            columnNumber: 23
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid h-full w-full place-items-center bg-emerald-50 text-emerald-700",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-sm font-semibold",
                                                children: (job.company_name || "?").slice(0, 1).toUpperCase()
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/find-job/page.tsx",
                                                lineNumber: 403,
                                                columnNumber: 25
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/find-job/page.tsx",
                                            lineNumber: 402,
                                            columnNumber: 23
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/find-job/page.tsx",
                                        lineNumber: 393,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "min-w-0 pr-14",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "font-semibold leading-5 break-words line-clamp-3 text-[15px]",
                                                children: job.job_title || job.position
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/find-job/page.tsx",
                                                lineNumber: 408,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-1 text-sm text-gray-600 break-words",
                                                children: job.company_user_id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    className: "hover:underline cursor-pointer",
                                                    href: "/profile/".concat(job.company_user_id),
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    children: job.company_name
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/find-job/page.tsx",
                                                    lineNumber: 411,
                                                    columnNumber: 25
                                                }, this) : job.company_name
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/find-job/page.tsx",
                                                lineNumber: 409,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-xs text-gray-500 break-words",
                                                children: (_job_location = job.location) !== null && _job_location !== void 0 ? _job_location : job.company_location
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/find-job/page.tsx",
                                                lineNumber: 418,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/find-job/page.tsx",
                                        lineNumber: 407,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-2 text-sm text-gray-700 line-clamp-3 break-words",
                                        children: job.description
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/find-job/page.tsx",
                                        lineNumber: 420,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-2 text-[11px] text-gray-500",
                                        children: [
                                            job.available_position,
                                            " position(s) | ",
                                            job.jobType
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/find-job/page.tsx",
                                        lineNumber: 423,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, job.id, true, {
                                fileName: "[project]/src/app/find-job/page.tsx",
                                lineNumber: 382,
                                columnNumber: 17
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/app/find-job/page.tsx",
                        lineNumber: 371,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "relative rounded-2xl border bg-white p-5 sm:p-6 shadow-sm sticky top-20 max-h-[72vh] overflow-y-auto break-words",
                        style: {
                            borderColor: GREEN
                        },
                        children: !selected ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-gray-600 text-sm",
                            children: "Select a job from the left panel."
                        }, void 0, false, {
                            fileName: "[project]/src/app/find-job/page.tsx",
                            lineNumber: 438,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "pr-20 space-y-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-2xl font-semibold",
                                                    children: selected.job_title || selected.position
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/find-job/page.tsx",
                                                    lineNumber: 446,
                                                    columnNumber: 19
                                                }, this),
                                                (selected === null || selected === void 0 ? void 0 : selected.id) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: "/job/".concat(selected.id),
                                                    className: "inline-flex items-center justify-center rounded-full border p-1 text-gray-600 hover:bg-gray-50",
                                                    title: "Open job details",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowTopRightOnSquareIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowTopRightOnSquareIcon$3e$__["ArrowTopRightOnSquareIcon"], {
                                                        className: "h-4 w-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/find-job/page.tsx",
                                                        lineNumber: 453,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/find-job/page.tsx",
                                                    lineNumber: 448,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/find-job/page.tsx",
                                            lineNumber: 445,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-base text-gray-600 break-words flex items-center gap-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BuildingOfficeIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BuildingOfficeIcon$3e$__["BuildingOfficeIcon"], {
                                                    className: "h-4 w-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/find-job/page.tsx",
                                                    lineNumber: 458,
                                                    columnNumber: 19
                                                }, this),
                                                selected.company_user_id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    className: "hover:underline cursor-pointer",
                                                    href: "/profile/".concat(selected.company_user_id),
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    children: selected.company_name
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/find-job/page.tsx",
                                                    lineNumber: 460,
                                                    columnNumber: 21
                                                }, this) : selected.company_name
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/find-job/page.tsx",
                                            lineNumber: 457,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm text-gray-500 break-words flex items-center gap-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MapPinIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPinIcon$3e$__["MapPinIcon"], {
                                                    className: "h-4 w-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/find-job/page.tsx",
                                                    lineNumber: 468,
                                                    columnNumber: 19
                                                }, this),
                                                (_selected_location = selected.location) !== null && _selected_location !== void 0 ? _selected_location : selected.company_location
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/find-job/page.tsx",
                                            lineNumber: 467,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/find-job/page.tsx",
                                    lineNumber: 444,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-3 flex flex-wrap gap-2 text-sm text-gray-700",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "inline-flex items-center rounded-full border border-gray-300 bg-white px-2.5 py-0.5",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-medium",
                                                children: selected.jobType || '-'
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/find-job/page.tsx",
                                                lineNumber: 474,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/find-job/page.tsx",
                                            lineNumber: 473,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "inline-flex items-center rounded-full border border-gray-300 bg-white px-2.5 py-0.5",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-medium",
                                                children: selected.work_place || '-'
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/find-job/page.tsx",
                                                lineNumber: 477,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/find-job/page.tsx",
                                            lineNumber: 476,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/find-job/page.tsx",
                                    lineNumber: 472,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-2 grid gap-1 text-sm text-gray-600",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                "Available Positions: ",
                                                selected.available_position
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/find-job/page.tsx",
                                            lineNumber: 481,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                "Expected Salary: ",
                                                typeof selected.minimum_expected_salary === 'number' && typeof selected.maximum_expected_salary === 'number' ? "".concat(selected.minimum_expected_salary.toLocaleString(), " - ").concat(selected.maximum_expected_salary.toLocaleString()) : '-'
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/find-job/page.tsx",
                                            lineNumber: 482,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/find-job/page.tsx",
                                    lineNumber: 480,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Markdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    className: "mt-4 text-base text-gray-700",
                                    content: selected.description
                                }, void 0, false, {
                                    fileName: "[project]/src/app/find-job/page.tsx",
                                    lineNumber: 490,
                                    columnNumber: 15
                                }, this),
                                canApply && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-6 flex justify-end",
                                    children: (()=>{
                                        const isApplied = !!selected && appliedIds.has(selected.id);
                                        const isInCart = !!selected && contains(selected.id);
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    disabled: isApplied,
                                                    className: "rounded-full px-6 py-2 text-sm font-semibold text-white ".concat(isApplied ? 'opacity-60 cursor-not-allowed' : ''),
                                                    style: {
                                                        backgroundColor: GREEN
                                                    },
                                                    onClick: !isApplied ? ()=>setIsApplyOpen(true) : undefined,
                                                    children: isApplied ? 'APPLIED' : 'APPLY'
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/find-job/page.tsx",
                                                    lineNumber: 499,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    disabled: isApplied || isInCart,
                                                    className: "rounded-full border px-4 py-2 text-sm ".concat(isApplied || isInCart ? 'opacity-60 cursor-not-allowed' : 'hover:bg-gray-50'),
                                                    onClick: ()=>selected && add(selected),
                                                    children: isInCart ? 'ADDED' : 'ADD TO LIST'
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/find-job/page.tsx",
                                                    lineNumber: 507,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/find-job/page.tsx",
                                            lineNumber: 498,
                                            columnNumber: 23
                                        }, this);
                                    })()
                                }, void 0, false, {
                                    fileName: "[project]/src/app/find-job/page.tsx",
                                    lineNumber: 493,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true)
                    }, void 0, false, {
                        fileName: "[project]/src/app/find-job/page.tsx",
                        lineNumber: 433,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/find-job/page.tsx",
                lineNumber: 370,
                columnNumber: 7
            }, this),
            canApply && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ApplyModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isApplyOpen,
                onClose: ()=>setIsApplyOpen(false),
                onSubmit: handleApply,
                resumes: resumes,
                jobTitle: (selected === null || selected === void 0 ? void 0 : selected.job_title) || (selected === null || selected === void 0 ? void 0 : selected.position),
                brandColor: GREEN
            }, void 0, false, {
                fileName: "[project]/src/app/find-job/page.tsx",
                lineNumber: 526,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/find-job/page.tsx",
        lineNumber: 279,
        columnNumber: 5
    }, this);
}
_s(FindJobPage, "0Lt3S5WIX41LcXePmuergtvUGE4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$ApplyCartContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApplyCart"]
    ];
});
_c = FindJobPage;
var _c;
__turbopack_context__.k.register(_c, "FindJobPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_8553b4d3._.js.map