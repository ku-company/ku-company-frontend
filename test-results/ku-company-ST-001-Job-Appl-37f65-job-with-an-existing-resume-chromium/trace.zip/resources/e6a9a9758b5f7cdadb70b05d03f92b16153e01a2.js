(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_8553b4d3._.js",
  "static/chunks/node_modules_@heroicons_react_24_outline_esm_9bb9bf4b._.js"
],
    source: "dynamic"
});
